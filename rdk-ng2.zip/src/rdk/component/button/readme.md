
# 按钮

## API

### Button

| 参数      | 说明             | 类型      | 默认值  |
|----------|------------------|----------|--------|
| width | 控件宽度 | string: number/px/% | 80px |
| height | 控件高度 | string: number/px/% | 28px |
| disabled | 按钮是否可以点击 | boolean | false |
