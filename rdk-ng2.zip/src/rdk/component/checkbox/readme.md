
# 多选框

## API

### Checkbox

| 参数      | 说明             | 类型      | 默认值  |
|----------|------------------|----------|--------|
| checked | 指定当前是否选中 | boolean或者CheckBoxStatus |  | false |
| disabled | 初始是否选中 | boolean | false |
| change | 变化时回调函数 | Function(e:Event) | - |
| setCheckboxStatus | 设置checkbox的状态(添加了一种中间状态)| boolean或者CheckBoxStatus| -|
