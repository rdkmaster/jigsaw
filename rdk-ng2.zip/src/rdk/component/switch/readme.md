
# 开关

## API

### switch

| 参数    |   说明         | 类型    | 默认值 |
|--------|--------------| -------| -----|
| checked  | 是否选中(支持双向绑定) | boolean  |  false |
| disabled | 是否禁用      |boolean | false|
| onLabel  | 选中显示的内容| string | - |
| offLabel | 非选中的内容 | string | -|
| change   | 变化时回调函数 |Function(c:checked)| - |


