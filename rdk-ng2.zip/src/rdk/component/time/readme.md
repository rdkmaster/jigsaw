
# 时间控件

## API

### Time

| 参数      | 说明             | 类型      | 默认值  |
|----------|------------------|----------|--------|
| width | 控件宽度 | string | 300px |
| date | 选择的时间值 `双绑` | string | - |
| dateChange | date变化的回调 | EventEmitter | - |
| dateLimitStart | 限制开始时间 | string | - |
| dateLimitEnd | 限制结束时间 | string | - |
| gr | 粒度 | string | - |
| inline | 是否显示输入框 | boolean | true |
