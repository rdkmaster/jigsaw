
# Component Data Relationship
![](image/comp-data-map.png)
