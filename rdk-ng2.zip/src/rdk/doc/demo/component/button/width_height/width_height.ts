import {Component} from "@angular/core";

@Component({
    templateUrl: 'width_height.html'
})
export class ButtonWidthHeightDemoComponent {

}

