import {Component} from "@angular/core";

@Component({
  templateUrl: 'clearable.html'
})
export class InputClearableDemoComponent {

}

