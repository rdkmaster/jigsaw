import {Component} from "@angular/core";

@Component({
  templateUrl: 'basic.html',
  styleUrls: ['basic.css']
})
export class ScrollbarBasicDemoComponent {

}

