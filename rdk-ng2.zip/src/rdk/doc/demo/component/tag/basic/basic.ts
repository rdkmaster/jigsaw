import {Component} from "@angular/core";

@Component({
    templateUrl: 'basic.html',
    styleUrls: ['basic.scss']
})
export class TagBasicDemoComponent {


}

