/**
 * Created by 6396000843 on 2017/8/17.
 */

var componentFiles = require("./menuFileTree");
var dbConnection = require("../service/db-connect");

var fs = require("fs");
var path = require('path');
var utils = require("../service/utils.js");

var sql_componentMenuNav = "insert into ued_component_menu_nav(menuId,name,label,level,parent,orderByNum,content) values(?,?,?,?,?,?,?)";
var sql_truncateMenuNav ="truncate table ued_component_menu_nav";

var menuDatas = utils.transToArray(componentFiles);

console.log(menuDatas);

insertData(menuDatas);

function insertData(datas){
    dbConnection.query(sql_truncateMenuNav,function (err, result) {
        if(err){
            console.log('[DELETE ERROR] - ',err.message);
        }
    });
    datas.forEach(function(row){
        //增
        dbConnection.query(sql_componentMenuNav,row,function (err, result) {
            if(err){
                console.log('[INSERT ERROR] - ',err.message);
            }
        });
    });
    dbConnection.end();
}