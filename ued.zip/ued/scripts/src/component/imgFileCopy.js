/**
 * Created by 6396000843 on 2017/8/17.
 */
//目的：把资源路径下所有组件规范文档的图片复制到ued-site/rdk/app/ued/web/src/doc/ued-design/img路径下
var path = require('path');
var utils = require("../service/utils.js");
var { UED_RESOURCE_PATH,UED_SITE_PATH } = require("../constant");

var allComponentImgPath = path.join(UED_RESOURCE_PATH,"/ued-resource/组件/imgs/组件"); //图片路径

var uedImgPath=path.join(UED_SITE_PATH,"rdk/app/ued/web/dist/web/doc/ued-design/img");  //图片移动到指定路径

utils.travel(allComponentImgPath,function(file){
    console.log(file);
    utils.copy(file,uedImgPath);
});


