/**
 * Created by 6396000843 on 2017/8/17.
 */

//1.生成菜单数据
// require("./generateMenu");
//2.图片转移到指定路径
// require("./imgFileCopy");
