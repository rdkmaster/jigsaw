/**
 * Created by 6396000843 on 2017/8/24.
 */
var path = require('path');
var utils = require("./service/utils.js");

const fixedPath = "ued"+path.sep+"scripts";
//../../ued.cfg 相对路径--->绝对路径,相对路径无法确定知道当前工作路径
var uedConfigPath = path.join(__dirname.slice(0,__dirname.indexOf(fixedPath)+3),"ued.cfg");

var configFile=utils.parseFile(uedConfigPath,"utf-8");

// ued-resource资源项目路径
exports.UED_RESOURCE_PATH = configFile["ued_resource_path"];

// 服务器IP地址
exports.SERVER_IP = configFile["server_ip"];

// ued网站部署路径
exports.UED_SITE_PATH = configFile["ued_site_path"];



