/**
 * Created by 6396000843 on 2017/8/23.
 */

var dbConnection = require("../service/db-connect");
var projectData = require("./project-data");
var utils = require("../service/utils");

var fileds = "ProjectName,Creator,creatorId,CreatTime,Updator,updaterId,UpdateTime,SerialNum,RequirementDoc,PrototypeView,ProjectImg,ProjectBrief,status";
var filedsOfhistory = "messageId,updator,updaterId,updateTime,message,SerialNum";
var filedsOfImages = "SerialNum,PrototypeImgUrl,imgType";

var add_tb_xplan_project_info = "insert into xplan_project_info_copy("+ fileds + ") values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
// var del_tb_xplan_project_info = "delete from xplan_project_info  where SerialNum=?";
var copy_xplan_project_info = "call ued_project_copy('0');"; //1--是活跃项目,0--是历史项目
var restore_xplan_project_info = "call ued_project_restore();";
var ued_project_update = "call ued_project_update();";
var add_tb_ued_project_history = "insert into ued_project_history("+ filedsOfhistory + ") values(?,?,?,?,?,?)";
var del_tb_ued_project_history = "delete from ued_project_history  where messageId=?";

var add_tb_xplan_prototype_images = "insert into xplan_prototype_images("+ filedsOfImages + ") values(?,?,?)";
var del_tb_xplan_prototype_images = "delete from xplan_prototype_images  where SerialNum=?";

var projectDataPromise = projectData.getProjectsData;

console.log("waiting......");
projectDataPromise.then(function(wholeProjectData){
    console.log("start insert project data to database");
    var tb_projectsData = utils.transToArray(wholeProjectData.tb_projectsData);
    var tb_projectHistoryData = utils.transToArray(wholeProjectData.tb_projectHistoryData);
    var tb_projectImages = utils.transToArray(wholeProjectData.tb_projectImages);
    dbConnection.connect();
    console.log("projects data: >>>>>");
    console.log(tb_projectsData);
    try{
        callProcedure(copy_xplan_project_info);
        insertDataToTbProject(tb_projectsData,add_tb_xplan_project_info);
        insertDataToTbProject(tb_projectHistoryData,add_tb_ued_project_history,del_tb_ued_project_history);
        insertDataToTbProject(tb_projectImages,add_tb_xplan_prototype_images,del_tb_xplan_prototype_images,0);
    }catch (e){
        console.log("data error >>>>>>:"+e)
    }finally {
        callProcedure(restore_xplan_project_info);
    }
    callProcedure(ued_project_update); //写入数据无错误才进行项目表数据的更新
    dbConnection.end();
    console.log("The database is closed and the data has been processed")
});

var lastKeyVal=null;
function insertDataToTbProject(datas,addSql,delSql,key){
    datas.forEach(function(row){
        //删掉旧数据
        if(!!delSql){
            if(lastKeyVal != row[key || 0]){
                dbConnection.query(delSql,row[key || 0],function (err, result) {
                    if(err){
                        console.log('[INSERT ERROR] - ',err.message);
                    }
                });
            }
            lastKeyVal = row[key || 0];
        }
        //增
        dbConnection.query(addSql,row,function (err, result) {
            if(err){
                console.log('[INSERT ERROR] - ',err.message);
            }
        });
    });
}

function callProcedure(sql){
    dbConnection.query(sql,function (err, result) {
        if(err){
            throw err;
        }
    });
}
