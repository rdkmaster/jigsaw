/**
 * Created by 6396000843 on 2017/8/23.
 */
var fs = require('fs');
var path = require('path');
var Q = require('q');
var async = require("async");
var utils = require("../service/utils");
var { UED_RESOURCE_PATH } = require("../constant");
var simpleGit = require('simple-git')(UED_RESOURCE_PATH);
const projectPath = path.join(UED_RESOURCE_PATH,"ued-resource/项目/[0历史项目]");  //历史项目原型存放路径

var projectFileList=[];

utils.travel(projectPath,function(file){
    var projectFile = path.relative(UED_RESOURCE_PATH,file);
    // var projectFile = projectFile.replace("/\\\/g",'/');
    while(projectFile.indexOf("\\")!=-1){
        projectFile=projectFile.replace("\\",'/');
    }
    projectFileList.push(projectFile);
},false);

var projectGitLogPromise=Q.defer();

async.mapLimit(projectFileList,10, function(projectFile, callback) {
    exportProjectGitLogInfo(projectFile,function(projectGitLogInfo){
        callback(null, projectGitLogInfo);
    })
}, function(err, results) {
    if(err){
        projectGitLogPromise.reject(err);
    }else{
        projectGitLogPromise.resolve(results);
    }
});

function exportProjectGitLogInfo(projectFile,cb){
    var project ={
        projectName:path.parse(projectFile).name,
        history:[]
    };
    //,"--date":'short' git log --pretty=format:"%h,%an,%ad,%s" --date=format:'%Y-%m-%d %H:%M:%S' -- "%1" > f:/gitlog/"%2"
    simpleGit.log({file:projectFile,"--pretty":'format:"%h,%an,%ad,%s"'},  function(err, log) {
        try {
            log.all.forEach(function(commitRecord,index){
                //创建人信息
                if(index==log.total-1){
                    project.creator = _getCreatorName(commitRecord.author_name);
                    project.creatorId = _getCreatorId(commitRecord.author_name);
                    project.history.push({
                        messageId:utils.generateId(),
                        updator:_getCreatorName(commitRecord.author_name),
                        updaterId:_getCreatorId(commitRecord.author_name),
                        date:_formatStrDate(commitRecord.date),
                        message:commitRecord.message.replace(/\(HEAD.*\)/g,"").trim()
                    });
                    project.creatTime=_formatStrDate(commitRecord.date);
                }
                //历史记录
                else{
                    project.history.push({
                        messageId:utils.generateId(),
                        updator:_getCreatorName(commitRecord.author_name),
                        updaterId:_getCreatorId(commitRecord.author_name),
                        date:_formatStrDate(commitRecord.date),
                        message:commitRecord.message.replace(/\(HEAD.*\)/g,"").trim()
                    });
                }
            });

            //最后更新人信息
            project.updator = _getCreatorName(log.latest.author_name);
            project.updatorId = _getCreatorId(log.latest.author_name);
            //服务端git用户名配置信息为root，服务端提交生成的id文件，破坏了项目的更新人
            project.updator = project.updator=="root" ? project.creator : project.updator;
            project.updatorId = project.updatorId=="root" ? project.creatorId : project.updatorId;

            project.updateTime = _formatStrDate(log.latest.date);
        }catch (e){
            console.log(e);
        }finally{
            cb(project);
        }
    })
}

function _formatStrDate(str){
    var result = str.split(" ");
    result.pop();
    return result.join(" ");
}
function _getCreatorName(str){
    //注意git 配置的用户名不符合 张三10010001 格式
    return !!str.match(/[\u4e00-\u9fa5]{2,}/g) ? str.match(/[\u4e00-\u9fa5]{2,}/g)[0]:str
}

function _getCreatorId(str){
    //注意git 配置的用户名不符合 张三10010001 格式
    return !!str.match(/(\d{1,3})+(?:\.\d+)?/g) ? str.match(/(\d{1,3})+(?:\.\d+)?/g)[0]:str
}

exports.projectGitLogPromise = projectGitLogPromise.promise;