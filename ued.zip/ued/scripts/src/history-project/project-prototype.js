/**
 * Created by 6396000843 on 2017/8/21.
 */

//目的：返回项目原型数据信息
var fs = require('fs');
var path = require('path');
var utils = require("../service/utils");
var archiver = require('archiver');

var { UED_RESOURCE_PATH,SERVER_IP } = require("../constant");
var serverPath = path.join(SERVER_IP,"ux");

const projectPath = path.join(UED_RESOURCE_PATH,"ued-resource/项目");  //活跃项目原型存放路径
const historyProjectPath = path.join(UED_RESOURCE_PATH,"ued-resource/项目/[0历史项目]");  //历史项目原型存放路径
//uedResourcePathBak 镜像存放项目打包的文件，以及UED上传的文件，nginx已配置ux-file路径
var pathArr=UED_RESOURCE_PATH.split(path.sep);
var uedResourcePathBak=path.join(pathArr.slice(0, pathArr.length-1).join(path.sep),"ux-file");

/*start*/
utils.travel(projectPath,function(file){
    var fileObj = path.parse(file);
    var projectName= fileObj.name;  //新建项目模板,此文件不进行任何操作
    if(projectName.indexOf("(模板)") ==-1 && projectName.indexOf("历史项目]") ==-1)  //忽略历史项目
    {
        isHistoryProject(file);
    }
},false);

function isHistoryProject(projectFile){
    var projectName= path.parse(projectFile).name;
    var stat = fs.statSync(projectFile);
    if(utils.timeDifference(stat.mtime)){
        console.log(projectName," 移动到历史项目中!!");
        fs.renameSync(projectFile, path.join(historyProjectPath,projectName));
    }
}

/*end*/
const projectFiled={
    prototypeImgUrl:"1头图",
    prototypeBrief:"项目简介",
    prototypeView:"2原型",
    requirementDoc:"4附件",
    prototypeImgUrlList:"3效果图"
};

var fileTree = {};

travel(historyProjectPath,function(file){

    var fileObj = path.parse(file);
    var projectName= fileObj.name;  //新建项目模板,此文件不进行任何操作
    if(!fileTree[projectName])  //忽略历史项目
    {
        fileTree[projectName]={};
        fileTree[projectName]["projectId"]=addIDToFile(file);
        fileTree[projectName]["prototypeImgUrlList"]=[];
        fileTree[projectName]["requirementDoc"]=[];
        fileTree[projectName]["prototypeView"]="";

    }
},false);

function addIDToFile(file){
    var id;
    var keyPath = path.join(file,".id");
    if(utils.fsExistsSync(keyPath)){
        id = fs.readFileSync(keyPath,"utf-8");
    }else{
        id = utils.generateId();
        fs.writeFileSync(keyPath, id);
    }
    //过滤空行换行符
    id = id.replace(/[\s\r\n]+/g,"");
    return id;
}
travel(historyProjectPath,function(file){
    //过滤模板和gitkeep文件
    if(file.indexOf("(模板)")!=-1 || file.indexOf("gitkeep")!=-1){
        return
    }

    var fileObj = path.parse(file);
    var parentPath = getParentDirectory(file);
    for(var project in fileTree){
        var projectName = path.sep+project; //项目名存在包含关系  一级文件目录
        if(fileTree.hasOwnProperty(project)){
            if(fileObj.dir.indexOf(projectName)!=-1){
                fileTree[project].projectName=project;
                for(filed in projectFiled){
                    var fileUrl = "http://"+path.join(serverPath,path.relative(UED_RESOURCE_PATH,file)).replace(/\\/g,'/');
                    // 二级文件目录
                    //fileObj.dir.indexOf(path.sep+projectFiled[filed])!=-1 || fileObj.name == projectFiled[filed]
                    if(parentPath == projectFiled[filed] || fileObj.name == projectFiled[filed]){
                        if(filed=="prototypeImgUrlList"){ //效果图
                            //fileTree[project]["prototypeImgUrlList"].push(encodeURI(fileUrl));
                            if(path.extname(fileUrl) !== ".zip"){  //查看效果图时会在项目效果图路径下打包成zip文件，过滤掉此文件
                                fileTree[project]["prototypeImgUrlList"].push(fileUrl);
                            }
                        }
                        else if(filed=="requirementDoc"){  //附件资源
                            var attachFile = {};
                            attachFile.name=fileObj.name;
                            attachFile.url=fileUrl;
                            fileTree[project]["requirementDoc"].push(JSON.stringify(attachFile));
                        }
                        else{
                            fileTree[project][filed]=fileUrl;
                        }
                    }
                }
            }
        }
    }
});

function travel(dir,callback,dep) {
    dep = dep==null?true:dep; //默认深度遍历到所有子文件
    fs.readdirSync(dir).forEach(function (file) {
        var pathname = path.join(dir, file);
        if(file.indexOf("(模板)")!=-1 || file.indexOf("gitkeep")!=-1){
            return
        }
        if(dep && fs.statSync(pathname).isDirectory()){
            var parentPath = getParentDirectory(pathname);
            //原型路径下的文件不需要在遍历，直接返回home.html
            if(file == "2原型"){
                var  timeStamp = new Date().valueOf();
                if(utils.fsExistsSync(path.join(pathname, 'home.html'))){ //如果存在home.html，原型就用home.html
                    callback(path.join(pathname, 'home.html?key='+timeStamp));
                }else{
                    callback(path.join(pathname, 'index.html?key='+timeStamp));
                }
            }else if(parentPath == "4附件"){
                //把附件下的文件夹压缩打包成一个zip文件，不再进行深度遍历
                if(fs.statSync(pathname).isDirectory()){
                    var bakPath=path.join(uedResourcePathBak,dir.slice(dir.indexOf("ued-resource")));
                    utils.mkdirsSync(bakPath);
                    var output = fs.createWriteStream(bakPath + '/'+file+'.zip');
                    var archive = archiver('zip', {zlib: { level: 9 }});
                    archive.pipe(output);
                    archive.directory(pathname, false);
                    archive.finalize();
                    //打包后的文件路径返回给callback
                    callback(path.join(bakPath + '/'+file+'.zip'));
                }
            }
            else if(file.indexOf("(模板)") ==-1){
                travel(pathname, callback);
            }
        }else{
            callback(pathname);
        }
    });
}

var result =[];

for(var p in fileTree){
    //头图，原型，附件,项目简介不存在时设为空;
    if(!fileTree[p]['prototypeView']){
        fileTree[p]['prototypeView']="";
    }
    if(!fileTree[p]['prototypeImgUrl']){
        fileTree[p]['prototypeImgUrl']="";
    }
    if(!fileTree[p]['requirementDoc']){
        fileTree[p]['requirementDoc']="";
    }else {
        fileTree[p]['requirementDoc']=JSON.stringify(fileTree[p]['requirementDoc']);
    }
    if(!fileTree[p]['prototypeBrief']){
        fileTree[p]['prototypeBrief']="";
    }
    fileTree[p]["status"]="0"; //全部标记为历史项目
    result.push(fileTree[p]);
}

function getParentDirectory(file){
    if(file==null||file==""){
        return "";
    }
    var filePath = file.split(path.sep);
    var len=filePath.length;
    if(len>=2){
        return filePath[filePath.length-2]
    }
    return filePath[filePath.length-1]
}
console.log("total:"+result.length+"hostory projects");
exports.projectProtoData = result;



