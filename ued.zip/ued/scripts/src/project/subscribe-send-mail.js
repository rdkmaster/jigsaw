const fs = require("fs");
const http = require('http');
const utils = require("../service/utils");

fs.readFile('/home/ued/ux-file/subscription/update-project-content.txt', function (err, data) {
    var doExecute;
    //判断是不是重复的邮件
    var timeData = fs.readFileSync('/home/ued/ux-file/subscription/last-time-push.txt');
    if (data.indexOf(timeData) === -1) {
        doExecute = true;
    } else {
        doExecute = false;
    }
    console.log(doExecute);
    var regAuthor = /Author:\s+([\u4e00-\u9fa5]{2,20})(\d{8,10})/;
    var regProject = /ued-resource\/项目\/([^\/\n]+)\//;
    var content = {
        author: [],
        projectNames: [],
        projects: []
    };
    var temp = data.toString().match(regAuthor)

    if (regAuthor.test(data) && doExecute) {

        content.author[0] = temp[1];
        content.author[1] = temp[2];

        var allProjectFiles = [];
        if (err) {
            return console.error(err);
        } else {
            var add = data.toString().split(/\n/);
            add = add.filter(function (val, index) {
                add = add.filter(function (val, index) {
                    if(/.*\/2原型\/.*/.test(val)){
                        if(/.*\/2原型\/[^\/]*\.html$/.test(val)){
                            return true;
                        }else{
                            return false;
                        }
                    }
                    return !!val;
                });
                return !!val;
            });

            add.forEach(function (val, index) {
                if (/^(D\s+|A\s+|M\s+)/.test(val) && !/(\.gitkeep|\.id)$/.test(val)) {
                    if(val.match(regProject)){
                        content.projectNames.push(val.match(regProject)[1]);
                        allProjectFiles.push(val);
                    }
                }
            });
            console.log(content.projectNames.lenght);
            content.projectNames = content.projectNames.removeDup() || [];

            content.projectNames.forEach(function (val, ind) {
                content.projects[ind] =
                    {
                        projectName: "",
                        proFiles: [],
                        encFiles: [],
                        desFiles: []
                    };
                content.projects[ind].projectID = fs.readFileSync("/home/ued/ux/ued-resource/项目/" + val + "/.id", "utf-8")
                content.projects[ind].projectName = val;

                allProjectFiles.forEach(function (src, index) {
                    var content1, typeEn, type;
                    if (src.indexOf(val) != -1) {
                        if (/.*\/2原型\/.*/.test(src)) {
                            content1 = src.match(/.*\/2原型\/(.*)/);
                            typeEn = src.slice(0, 1);
                            type = typeEn === "A" ? "添加" : typeEn === "D" ? "删除" : "修改";
                            content.projects[ind].proFiles.push({type: type, content: content1[1]});
                        } else if (/.*\/3效果图\/.*/.test(src)) {
                            content1 = src.match(/.*\/3效果图\/(.*)/);
                            typeEn = src.slice(0, 1);
                            type = typeEn === "A" ? "添加" : typeEn === "D" ? "删除" : "修改";
                            content.projects[ind].encFiles.push({type: type, content: content1[1]});
                        } else if (/.*\/4附件\/.*/.test(src)) {
                            content1 = src.match(/.*\/4附件\/(.*)/);
                            typeEn = src.slice(0, 1);
                            type = typeEn === "A" ? "添加" : typeEn === "D" ? "删除" : "修改";
                            content.projects[ind].desFiles.push({type: type, content: content1[1]});
                        }
                    }
                });

            });
        }
    }else{

        return false;
    }
    fs.writeFile('/home/ued/ux-file/subscription/update-project-content.json', JSON.stringify(content), function (err) {
        if (err) {
            console.log('写入失败');
        } else {
            console.log("成功")
            //邮件发送的数据
            fs.appendFile('/home/ued/ux-file/subscription/log.txt', JSON.stringify(content)+"\n\n+++++++++++++++++++++", function (err) {
                if(err){
                    console.log("写入失败")
                }else{
                    console.log("成功")
                }
            });


            var options = {
                hostname: 'rdk.zte.com.cn',
                port: 40080,
                path: '/rdk/service/app/ued/server/project/sendsub',
                method: 'GET'
            };

            var req = http.request(options, function (res) {
                console.log('STATUS: ' + res.statusCode);
                console.log('HEADERS: ' + JSON.stringify(res.headers));
                res.setEncoding('utf8');
                res.on('data', function (data) {
                    console.log(data);
                });
            });

            req.on('error', function (e) {
                console.log('problem with request: ' + e.message);
            });

            req.end();
        }
    });

});



