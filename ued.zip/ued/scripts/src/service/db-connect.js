var mysql      = require('mysql');
var connection = mysql.createConnection({
    host     : '10.9.225.190',
    user     : 'root',
    password : 'ux123~',
    database : 'xplan',
    stringifyObjects:true
});

module.exports = connection;