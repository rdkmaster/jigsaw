/**
 * 功能：提供UED文件上传服务
 */
var express = require('express');
var multer  = require('multer');
var fs = require("fs");
var path = require("path");
var upload = multer();
var app = express();
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

var utils = require("../service/utils");

app.get('/file-upload/test', function (req, res) {
    res.send("hello !!!");
});
/*
* 上传用户头像服务  用户头像文件命名 u+工号形式
* 头像存储路径 /home/ued/ux-file/upload/images/head/u6396000843.jpeg
* */
app.post("/file-upload/service/userhead", multipartMiddleware, function (req, res) {
    //文件
    const uid=req.query.uid;
    const photoData = req.files.files;
    //文件路径
    const filePath = photoData.path;
    //读取文件
    fs.readFile(filePath, function (err, data) {
        //取文件类型
        var type = photoData.type.split('/')[1];
        type = type=== "plain" ? type="txt": "png";
        //命名文件
        const fileName = "u" + uid + '.' + type;
        //存储路径
        const newPath = path.join(__dirname.slice(0,__dirname.indexOf("ued-site")), 'ux-file/upload/images/head/');
        utils.mkdirsSync(newPath); //判断此存储路径是否存在，没有则创建
        const filePath=path.join(newPath,fileName); //文件路径
        //最后返回文件引用路径
        const replyPath = path.join('/ux-file/upload/images/head',fileName);
        //写入文件
        fs.writeFile(filePath, data, function (err) {
            //返回状态1表示成功，返回的数据是存储后的文件名
            res.end(replyPath+"?timestamp="+Date.now());
        })
    });
});


/**
 * 上传文件服务，任何文件
 * 文件存储路径 /home/ued/ux-file/upload/files/2018/01/29/filename
 */
app.post("/file-upload/service/common", multipartMiddleware, function (req, res) {
    //文件
    const fileObject = req.files.files;
    //文件路径
    const filePath = fileObject.path;
    //读取文件
    fs.readFile(filePath, function (err, data) {
        //命名文件
        const fileName = fileObject.name;
        //存储路径
        const date=new Date().Format("yyyy/MM/dd");
        const newPath = path.join(__dirname.slice(0,__dirname.indexOf("ued-site")),'ux-file/upload/files',date);
        utils.mkdirsSync(newPath); //判断此存储路径是否存在，没有则创建
        const filePath=path.join(newPath,fileName); //文件路径
        const replyPath = path.join('/ux-file/upload/files',date,fileName);
        //写入文件
        fs.writeFile(filePath, data, function (err) {
            res.end(replyPath);
        })
    });
});

app.listen("30080", "0.0.0.0", function () {
    console.log("文件上传服务已启动> http://localhost:30080");
});