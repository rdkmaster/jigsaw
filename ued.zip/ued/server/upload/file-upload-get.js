/**
 * Created by 6396000843 on 2017/9/18.
 *
 * 功能：提供UED文件上传接口
 */
(function() {
    return function(request, script) {
        log("file upload...............");
        log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");


        //File.loadProperty("app/ued/ued.cfg");
        var data=new Date().format("yyyy/MM/dd");

        // var a=File.save("app/ued/"+data+"/test2.png","content22222");

        return data
    }
})();