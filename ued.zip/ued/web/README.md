# Jigsaw Seed
这是组件库[Jigsaw](https://github.com/rdkmaster/jigsaw)的种子工程，建议所有新增的app都以这个工程作为种子开始构建。[具体步骤看这里](https://github.com/rdkmaster/jigsaw#全新的开始)。
