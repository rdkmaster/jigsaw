/**
 * Created by 6396000843 on 2017/9/19.
 */
import { Injectable }    from '@angular/core';
import { CanActivate,CanActivateChild,Router,ActivatedRouteSnapshot,RouterStateSnapshot } from '@angular/router';
import { Observable } from "rxjs/Observable";
import {UserLoginService} from "../user/user-login/user-login.service";

import {JigsawWarningAlert} from "@rdkmaster/jigsaw";

@Injectable()
export class CanActivateGuard implements  CanActivate,CanActivateChild {

  constructor(private userLoginService:UserLoginService,
              private router: Router
  ){}

  loginMsg=null;
  canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot):Observable<boolean>|Promise<boolean>|boolean {

    if(this.userLoginService.isLogin || !!this.userLoginService.currentUserGlobal) return true;
    this.userLoginService.redirectUrl = state.url;
    this.userLoginService.openLoginProp$.next(true);

    if(this.loginMsg){
      return false;
    }else{
      setTimeout(()=>{
        this.loginMsg=JigsawWarningAlert.show('', answer => {},[],'请先登陆', false);
        setTimeout(()=>{
          this.loginMsg.dispose();
          this.loginMsg=null;
        },2000)
      },0);
    }
    return false;
  }

  canActivateChild(childRoute:ActivatedRouteSnapshot, state:RouterStateSnapshot):Observable<boolean>|Promise<boolean>|boolean {
    return this.canActivate(childRoute, state);
  }
}
