/**
 * Created by 6396000843 on 2017/11/23.
 */
import { Injectable }    from '@angular/core';
import { Http } from '@angular/http';
import {UserLoginService} from "../../user/user-login/user-login.service";
import { environment } from '../../../environments/environment';
@Injectable()
export class VersionControlService {

  static versionFlag:string =environment.version;

  static  get version():Version{
    return UedVersion[environment.version]
  }
}

export class Version {
  public showProjectModule;
  public showRegister;
  public loginPlaceholder;

  constructor(obj){
    this.showProjectModule=obj.showProjectModule;
    this.showRegister=obj.showRegister;
    this.loginPlaceholder=obj.loginPlaceholder;
  }
}

const  UedVersion ={
  "outward":new Version({
    showProjectModule:false,
    showRegister:true,
    loginPlaceholder:"用户"
  }),
  "inward": new Version({
    showProjectModule:true,
    showRegister:false,
    loginPlaceholder:"8位或10位工号"
  })
};


