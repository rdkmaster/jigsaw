/**
 * Created by 6396000843 on 2017/11/23.
 */

import { Injectable }    from '@angular/core';
import {HttpEvent, HttpClient,HttpInterceptor, HttpHandler, HttpRequest,HttpResponse} from '@angular/common/http';
import { Observable }    from 'rxjs/Observable';
import {Subject} from "rxjs/Subject";
import 'rxjs/add/operator/do';
import {VisitRecordService} from "./visit-record.service";

@Injectable()
export class VisitRecordInterceptor implements HttpInterceptor {

  constructor(private visitRecordService:VisitRecordService){
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    try {
      this.visitRecordService.recordUserVisitData(req);
    }catch (e){
      console.error("visitRecordService error :" + e)
    }
    return next.handle(req)
  }
}
