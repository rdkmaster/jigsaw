/**
 * Created by 6396000843 on 2017/11/23.
 */

export  class  VisitRecord{
  tbName:string;  //表名
  tbIdField:string; //表主键字段
  tbIdValue:string; //表主键值
  recordNumField:string; //记录数字段
  visitUserId:string; //访问用户id
  visitDate:string; //访问时间

  constructor(tbName:string,tbIdField:string,recordNumField:string,visitUserId ?: string,tbIdValue ?: string){
    this.tbName=tbName;
    this.tbIdField=tbIdField;
    this.recordNumField=recordNumField;
    this.visitUserId=visitUserId || "";
    this.tbIdValue=tbIdValue || "";
  }

  public setTbIdValue(tbIdValue:string){
    this.tbIdValue=tbIdValue;
  }

  public setVisitUserId(uid:string){
    this.visitUserId=uid;
  }

  public setVisitDate(date:string){
    this.visitDate=date;
  }

  private static visitRecord: VisitRecord = null;
  private static cachedUrl = '';

  static getInstance(visitUrl:string):VisitRecord{
    if(visitUrl !== this.cachedUrl){
      this.cachedUrl=visitUrl;
      let recordItem = recordUrlCfg.find(item => item.visitUrl==visitUrl);
      this.visitRecord=!!recordItem ? recordItem["visitRecord"] : null
    }
    return this.visitRecord;
  }
}

//对配置的特定url进行用户访问统计
const recordUrlCfg=[
  {
    visitUrl:"rdk/service/app/ued/server/post/post-detail",
    visitRecord:new VisitRecord("ued_article","articleId","VisitRecord")
  },
  {
    visitUrl:"rdk/service/app/ued/server/project/projectDetail",
    visitRecord:new VisitRecord("xplan_project_info","SerialNum","VisitRecord")
  },
];
