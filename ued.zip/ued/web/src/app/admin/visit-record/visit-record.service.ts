/**
 * Created by 6396000843 on 2017/11/23.
 */

import { Injectable }    from '@angular/core';
import { Http } from '@angular/http';
import { VisitRecord } from "./visit-record.model";

import * as moment from "moment";
import {UserLoginService} from "../../user/user-login/user-login.service";

@Injectable()
export class VisitRecordService {

  private visitRecord:VisitRecord;

  private recordUrl = '/rdk/service/app/ued/server/user/visit-record';

  constructor(
    private http:Http,
    private userLoginService:UserLoginService
  ){}

  public recordUserVisitData(req:any) : void{
    if(!req){
      return
    }

    let url = req.url.slice(0,req.url.indexOf("?"));
    this.visitRecord=VisitRecord.getInstance(url);

    if(this.visitRecord){
      let param=this._getUrlQueryParam(req.url,this.visitRecord.tbIdField);
      param=this._formatParamer(param);
      this.visitRecord.setTbIdValue(param);
      this.visitRecord.setVisitDate(moment().format('YYYY-MM-DD HH:mm:ss'));

      let currentUser = this.userLoginService.currentUserGlobal;
      if(currentUser){
        this.visitRecord.setVisitUserId(currentUser.uid+'');
      }else{
        this.visitRecord.setVisitUserId("-1"); //游客身份访问
      }

      this.http
        .post(this.recordUrl,this.visitRecord)
        .subscribe()
    }
  }

  private _getUrlQueryParam(url:string,name:string)
  {
    var reg = new RegExp("(^|&)?"+ name +"=([^&]*)(&|$)");
    var r = url.substr(1).match(reg);
    if(r!=null) return  window["unescape"](r[2]);
    return null;
  }

  private _formatParamer(param) {
    // 空值直接返回.
    if(!param) return "";
    // 安全校验过滤
    return String(param).replace(/&|<|>|\'|\"/g,"");
  }
}
