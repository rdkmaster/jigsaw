import { NgModule }             from '@angular/core';
import {RouterModule, Routes, Router} from '@angular/router';

import { HomeComponent }  from './home/home.component';
import {PageNotFoundComponent} from "./page-not-found/page-not-found.component";
import {GlobalSearchComponent} from "./home/global-search/global-search.component";
import {VersionControlService} from "./admin/version/version-control.service";
import {AppAnalysisService} from "./app.analysis.service";

var routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home',     component: HomeComponent},
  { path: 'search', component: GlobalSearchComponent },
  { path: 'projects', loadChildren: './projects/projects.module#ProjectModule'},
  { path: 'designs', loadChildren: './designs/components.module#ComponentsModule'},
  { path: 'components', loadChildren: './components/components.module#ComponentsModule'},
  { path: 'post', loadChildren: './post/post.module#PostModule'},
  { path: 'tools', loadChildren: './tools/tools.module#ToolsModule'},
  { path: 'team', loadChildren: './team/team.module#TeamModule'},
  { path: '**', component: PageNotFoundComponent }
];
if(VersionControlService.versionFlag=="outward"){
  routes = routes.filter(item=>{
    return item.path!="projects"
  })
}

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  providers: [ AppAnalysisService ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {
  constructor(public router: Router, private analysis: AppAnalysisService) {
    analysis.addRouterListener(router);
  }
}
