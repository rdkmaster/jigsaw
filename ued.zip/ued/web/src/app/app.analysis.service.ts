import {Injectable, Inject} from "@angular/core";
import {Router, NavigationEnd} from "@angular/router";
import { PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

/**
 * Created by 10177553 on 2018/3/13.
 */

/**
 * 主要用户网站信息监控服务.
 */
@Injectable( )
export class AppAnalysisService {
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  public addRouterListener(router: Router) {
    router.events.filter(e => e instanceof NavigationEnd).subscribe(e => {
      if (isPlatformBrowser(this.platformId)) {
        this.openNewPage();
      }
    });
  }

  private get paq() {
    return window["_paq"] ? window["_paq"] : {push: (p:any) => {}};
  }

  /**
   * 设置登录用户. 以供统计信息服务使用
   * @param uid
   */
  public setUserInfo(uid) {
    this.paq.push(['setUserId', uid]);
    this.paq.push(['trackPageView']);
  }

  /**
   * 注销后, 调用这个服务, 重新设置用户ID
   */
  public resetUser() {
    // 暂时不支持, 注销用户.
    this.paq.push(['resetUserId']);
    this.paq.push(['trackPageView']);
  }

  private openNewPage() {
    let currentUrl = window.location.href;
    let _paq = this.paq;
    _paq.push(['setCustomUrl', currentUrl]);

    // remove all previously assigned custom variables, requires Matomo 3.0.2
    _paq.push(['deleteCustomVariables', 'page']);
    _paq.push(['setGenerationTimeMs', 0]);
    _paq.push(['trackPageView']);

    // make Matomo aware of newly added content
    let content = document.getElementById('content');
    _paq.push(['MediaAnalytics::scanForMedia', content]);
    _paq.push(['FormAnalytics::scanForForms', content]);
    _paq.push(['trackContentImpressionsWithinNode', content]);
    // _paq.push(['enableLinkTracking']);
  }
}
