import {Component, OnInit,ViewChild,AfterViewChecked, NgZone} from '@angular/core';
import { PLATFORM_ID ,Inject} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { GlobalService } from "./admin/global.service";
import { Router,NavigationStart } from '@angular/router';
import {PerfectScrollbarDirective} from "ngx-perfect-scrollbar";
import { VersionControlService} from "./admin/version/version-control.service";

import { environment } from '../environments/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: []
})
export class AppComponent implements OnInit,AfterViewChecked {

  isHomePage: boolean = false;
  isBrowser:boolean=true;
  @ViewChild(PerfectScrollbarDirective) directiveScroll: PerfectScrollbarDirective;

  constructor(
    private globalService: GlobalService,
    private router: Router,
    private zone: NgZone,
    @Inject(PLATFORM_ID) private platformId : Object
  ) {}

  ngOnInit() {

    if(this.router.url.match(/(home$)/gi)){
      this.isHomePage = true;
    }
    this.globalService.ifHomePage
      .subscribe(
        (isHomePage: boolean) => {
          this.isHomePage = isHomePage
        }
      );
    if (!isPlatformBrowser(this.platformId)) {
      this.isBrowser=false;
    }
    //else{
    //  this.router.events.subscribe(event => {
    //    if(event instanceof NavigationStart){
    //      console.log("用户访问....xxxxxxxxxxx"+event['url']);
    //      //兼容eban的老项目查看
    //      if(event['url'] && event['url'].match(/(project[^s])|(guideline)|(resource)/gi)){
    //        window.location.href=`http://10.9.225.190:20080${event['url']}`;
    //      }
    //    }
    //  });
    //}
  }

  ngAfterViewChecked():void {
    if (isPlatformBrowser(this.platformId)) {
      this.zone.runOutsideAngular(()=>{
        // this.directiveScroll.update();
      });
    }
  }
}


