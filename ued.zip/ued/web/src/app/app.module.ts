import {BrowserModule} from '@angular/platform-browser';
import {NgModule,enableProdMode} from '@angular/core';
enableProdMode();
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http'; // ng2 的http模块
import {HttpClientModule,HTTP_INTERCEPTORS} from '@angular/common/http'; //ng4 的http模块
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

/*路由&守卫*/
import { AppRoutingModule }     from './app-routing.module';
import { CanActivateGuard} from "./admin/auth-guard";
import { CanDeactivateGuard } from "./admin/can-deactivate-guard.service";
/*模块*/
import { HomeModule } from "./home/home.module";
import { UserModule } from "./user/user.module";
import { UedCommonModule } from "./common/ued-common.module";
/*模块 第三方*/
import { PerfectScrollbarModule } from "ngx-perfect-scrollbar";
import {JigsawButtonModule, JigsawRootModule} from "@rdkmaster/jigsaw";
import { GrowlModule} from 'primeng/primeng';
/*组件*/
import { AppComponent } from './app.component';

import { HomeComponent }  from './home/home.component';
import { UserCenterComponent } from './user/user-center/user-center.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
/*服务*/
import { GlobalService} from "./admin/global.service";
import { UserLoginService } from "./user/user-login/user-login.service";
import { SearchService } from "./home/global-search/search.service";
import { MessageService} from 'primeng/components/common/messageservice';
import { VisitRecordInterceptor } from "./admin/visit-record/visit-record-interceptor";
import { VisitRecordService } from "./admin/visit-record/visit-record.service";
import { VersionControlService} from "./admin/version/version-control.service";

import { Message} from 'primeng/primeng';
import {PowerGuard} from "./user/guards/power.guard";

@NgModule({
  declarations: [  //declarations数组包含应用中属于该模块的组件、管道和指令的列表
    AppComponent,
    HomeComponent,
    PageNotFoundComponent,
    UserCenterComponent,
  ],
  imports: [
    BrowserModule.withServerTransition({appId: 'zte-ued'}),
    GrowlModule,
    HomeModule,
    UserModule,
    UedCommonModule,PerfectScrollbarModule,
    FormsModule,ReactiveFormsModule , //<-- import the FormsModule before binding with [(ngModel)]
    HttpModule,HttpClientModule,
    JigsawRootModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    JigsawButtonModule
  ],
  providers: [
    UserLoginService,
    SearchService,
    MessageService,
    CanDeactivateGuard,
    CanActivateGuard,
    PowerGuard,
    GlobalService,
    VersionControlService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: VisitRecordInterceptor,
      multi: true,
    },VisitRecordService
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
