import {
  AfterContentInit, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges,
  ViewChild
} from '@angular/core';
import {Subject} from "rxjs/Subject";
import {CommonUtils} from "@rdkmaster/jigsaw";

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss'],
})
export class InputComponent implements OnInit,OnChanges,AfterContentInit {

  constructor() { }
  _value: string;
  _placeholder: string ;
  @Input() isfocus: boolean = false;
  @Input() width: string = '236px';
  @Input() height: string = '30px';
  @Input() iconName: string = 'fa-search';//fa-user-plus
  @ViewChild('eleInput') _elementRef;
  // @Output('stateValue') stateValue = new EventEmitter();
  @Output() valueChange = new EventEmitter();
  @Input()
  get value() {
    return this._value;
  }
  set value(newValue) {
    this._value = newValue;
    if (this._value != newValue) {
      this._value = CommonUtils.isDefined(newValue) ? newValue : '';
    }
    this.valueChange.emit(this._value);
  }

  @Input()
  public set placeholder(txt: string) {
    this._placeholder = txt;
  }
  public get placeholder() {
    return this._placeholder;
  }
  _clearValue(){
    this.value = "";
    this._elementRef.nativeElement.value = "";
    this.valueChange.emit("")
  }
  _updata(f){
    this.value = this._elementRef.nativeElement.value;
    this.valueChange.emit(this._elementRef.nativeElement.value)
  }
  public _$stopPropagation(event) {
    event.preventDefault();
    event.stopPropagation();
  }
  ngOnInit() {
  }
  ngOnChanges(changes: SimpleChanges) {
    if(changes.isfocus&&changes.isfocus.currentValue){
      setTimeout(()=>{
        this._elementRef.nativeElement.focus()
      },0)
    }
  }
  ngAfterContentInit(){
    setTimeout(()=>{
      this._elementRef.nativeElement.focus()
    },0)

  }
}
