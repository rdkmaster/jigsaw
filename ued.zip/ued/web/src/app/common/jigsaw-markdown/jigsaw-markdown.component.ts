import {
  Component, OnInit, Input, AfterViewInit, OnChanges, ViewEncapsulation, Renderer2,
  ViewChild
} from '@angular/core';
import { SimpleChange } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import  md from 'markdown-it';
import  hljs from 'highlight.js';
import  mdContainer from 'markdown-it-container';
import {slideAnimation} from "../../animations/animate";

@Component({
  selector: 'jigsaw-markdown',
  template: `
      <div class="jigsaw-markdown-option" *ngIf="labelTypes.length">
        <select name="" id="" [(ngModel)]="defaultLabelType" (ngModelChange)="doChangeLabelType()">
          <option [value]="option" *ngFor="let option of labelTypes">{{option}}</option>
        </select>
      </div>
      <div  >
        <div [@slideAnimation]="slideParam" (@slideAnimation.done)="animationDone($event)" #jgMarkdown class="jigsaw-markdown"  (click)="doMdContent($event)" [innerHtml]="renderContent|sanitizeHtml">
        </div>
        <div class="spread-box" >
          <div (click)="allText()" *ngIf="isSpread&&ellipsis"  class='spread'>{{actionHints}}&nbsp;<i [ngClass]="{'pack-down':!isPackUp,'pack-up':isPackUp}"></i></div>
        </div>
      </div>
      
    `,
  styleUrls: ['./jigsaw-markdown.component.scss'],
  animations:[slideAnimation],
  encapsulation: ViewEncapsulation.None
})
export class JigsawMarkdownComponent implements OnInit,OnChanges {

  @Input() mdSource:string;
  @Input() ellipsis:boolean = false; //是否现显收起展开键，字符串长度大于100时显示出来

  renderContent:string = ''; //渲染后的html
  cutOutContent: string; //截取后的html
  mdText:string = ""; //渲染前md原始内容
  private marked:any;
  defaultLabelType:any = "R";
  labelTypes:string[] = [];
  isSpread: boolean = false;
  isPackUp: boolean = true;
  actionHints: string = '展开';
  slideParam: string = "" ;
  @ViewChild('jgMarkdown') jgMarkdown: any;
  constructor(
    private http:Http,
    private _renderer: Renderer2,
  ) {

    let option = {
      html: true,
      breaks: false,
      langPrefix: 'language-',
      linkify: true,
      typographer: true,
      quotes: '“”‘’',
      highlight: function (str, lang) {
        if (lang && hljs.getLanguage(lang)) {
          try {
            return hljs.highlight(lang, str).value;
          } catch (__) {
          }
        }
        return '';
      }
    };
    this.marked = md(option);
    this.marked.use(mdContainer, 'left')
      .use(mdContainer, 'right')
      .use(mdContainer, '', {   // 文字内容也根据项目类型（-R,-O）变化
        validate: function (params) {
          return !!params.trim().match(/^\*.*$/);
        },
        render: (tokens, idx)=> {
          let m = tokens[idx].info.trim().match(/^R\s+(.*)$/);
          let token = tokens[idx];
          //md.utils.escapeHtml(m[1])
          if (token.nesting === 1) {
            // opening tag
            //return '<details><summary></summary>\n';
            if (token["info"].trim().replace(/\*/gi, "") != this.defaultLabelType) {
              return '<span class="test md-hide">';
            }
            else {
              return '<span class="test">';
            }
          } else {
            return '</span>';
          }
        },
        marker: "@"
      })
      .use(mdContainer, 'wrap', {marker: "!"});

    this.labelTypes = [];
    this._renderImgRules();
  }

  animationDone(event){
    if(event.toState==='down'){
        this.renderContent = this.cutOutContent;
    }
  }
  ngOnInit() {
    this.getMdText();
  }

  ngOnChanges():void {
    this.getMdText();
  }

  doChangeLabelType() {
    this._renderMdText();
  }

  private getMdText() {
    if (!this.mdSource) {
      this.renderContent = "";
      return
    }
    if (!!this.mdSource.match(/\.(md)|(txt)$/) || this.mdSource.match(/^rdk\/service/)) {
      let url;
      if(this.mdSource.match(/\d+\.\d+\.\d+\.\d+/)){
        //不用完整的url地址，域名，ip不能同时访问，用pathname
        let urlObj = this.parseUrl(this.mdSource);
        url = urlObj["path"];
      }else{
        url = this.mdSource;
      }
      this.renderContent = "<div><img src='assets/img/load.gif' width='120' height='120' alt=''></div> ";
      this.http
        .get(url)
        .map(response => {
          try {
            return response.json()
          } catch (e) {
            return response["_body"]
          }
        })
        .subscribe(mdText => {
          if (typeof mdText == "object") {
            mdText.data = mdText.data || "<h1>文档内容是空的！</h1>";
            this.mdText = mdText.data;
          } else {
            this.mdText = mdText;
          }
          this._renderMdText()
        });
    } else {
      this.renderContent = this.marked.render(this.mdSource);
    }
  }
  public renderText(){
    let reg = /.txt$/i;
    if(reg.test(this.mdSource)){
      this.renderContent=this.mdText.replace(/\n/ig,"<br>");
      this.renderContent=this.renderContent.replace(/\s/ig,"&nbsp;")
    }else{
      this.renderContent =this.marked.render(this.mdText);
    }
  }
  public allText(){
    if(!(this.isSpread && !this.isPackUp)){
      this.renderText();
    }
    this.isPackUp = !this.isPackUp;
    this.actionHints = this.isPackUp?'展开':'收起';
    this.slideParam = this.isPackUp?'down':'up';
  }
  private _renderMdText() {
    let reg = /.txt$/i;
    let tempText = this.mdText.replace(/\n|\s|\r/ig,"")
    if(this.ellipsis&&tempText.length>123&&reg.test(this.mdSource)){
      this.cutOutContent = tempText.slice(0,120)+"…";
      this.renderContent = this.cutOutContent;
      this.isSpread = true;
      this.slideParam = "down"
    return;
    }
    this.renderText()
  }

  private _renderImgRules() {

    this.marked.renderer.rules.image = (tokens, idx, options, env, slf)=> {
      let token = tokens[idx];
      let imgTagContent = this._parseMdTag(token["content"]);
      if (!this.labelTypes.includes(imgTagContent) && token["content"].indexOf("*") != -1) {
        this.labelTypes.push(imgTagContent);
        this.defaultLabelType = this.labelTypes[0];
      }

      let src = token.attrs[token.attrIndex('src')][1];
      token.attrs[token.attrIndex('src')][1] = src.replace(src.slice(0, src.lastIndexOf("/") + 1), "doc/ued-design/img/");
      token.attrs[token.attrIndex('alt')][1] = slf.renderInlineAsText(token.children, options, env);
      let imgTag = slf.renderToken(tokens, idx, options);
      if (imgTagContent != this.defaultLabelType && token["content"].indexOf("*") != -1) { // 图片根据项目类型（-R,-O）切换
        return "";
      }
      else if (imgTagContent == this.defaultLabelType) {
        return "<div class='image-container'>" + imgTag + "<div class='img-label'>" + imgTagContent + "</div></div>";
      }
      return "<div class='image-container'>" + imgTag + "</div>"
    };
  }

  isFirst:boolean = true;
  imgContainerCopy:HTMLElement;

  private _parseMdTag(content:string):string {
    return !!content ? content.replace(/\*/gi, "") : content
  }


  doMdContent($event) {
    let target = $event.target;
    if (target.nodeName === "IMG") {
      if (this.isFirst) {
        this.imgContainerCopy = target.parentNode.cloneNode(true);
        this.imgContainerCopy.style.opacity = "0";
        this.animateStart(target);
        target.parentNode.parentNode.appendChild(this.imgContainerCopy)
      } else {
        target.parentNode.parentNode.removeChild(this.imgContainerCopy);
        this.animateOver(target);
      }
      this.isFirst = !this.isFirst;
      target.parentNode.classList.toggle("animate-img-wrap");
      target.classList.toggle("animate-img");
    }
  }

  private animateStart(ele:HTMLElement) {
    let boxRect = ele.getBoundingClientRect();
    ele.style.position = "fixed";
    ele.style.left = boxRect.left + "px";
    ele.style.top = boxRect.top + "px";
    ele.style.cursor = "zoom-out";

    let bodyWidth = document.documentElement.clientWidth;
    let bodyHeight = document.documentElement.clientHeight;

    let imgScale=1;
    if( bodyWidth/bodyHeight >= boxRect.width/boxRect.height ){
      imgScale=(bodyHeight-100)/boxRect.height;
    }else{
      imgScale=(bodyWidth-100)/boxRect.width;
    }
    let centerX = (bodyWidth - boxRect.width) / 2;
    let centerY = (bodyHeight - boxRect.height) / 2;

    ele.style.transform = "translate(" + (-boxRect.left + centerX) + "px," + (-boxRect.top + centerY) + "px) scale("+ imgScale +")";
  }

  private animateOver(ele:HTMLElement) {
    ele.style.position = "";
    ele.style.transform = "";
    ele.style.cursor = "zoom-in";
  }

  private parseUrl(url:string){
    let reg = /^(?:([A-Za-z]+):)?(\/{0,3})([0-9.\-A-Za-z]+)(?::(\d+))?(?:\/([^?#]*))?(?:\?([^#]*))?(?:#(.*))?$/;
    let result = reg.exec(url);
    let names = ['url', 'scheme', 'slash', 'host', 'port', 'path', 'query', 'hash'];
    let urlObj = {};
    for (var i = 0, len = names.length; i < len; i++) {
      urlObj[names[i]] = result[i]
    }
    return urlObj;
  }
}

