import {
  Component, OnInit, Input,
  animate,
  style,
  transition,
  trigger,
  state, Output, EventEmitter
} from '@angular/core';

@Component({
  selector: 'app-slide-img',
  templateUrl: './slide-img.component.html',
  styleUrls: ['./slide-img.component.css'],
  animations: [
    trigger('imgMove', [
      /** 不显示 */
      state('off', style({'display': 'none', 'z-index': '0', 'transform': 'translateX(0)'})),
      /** 上一张图片 */
      state('prev', style({'z-index': '1',
        'transform': 'translateX(-100%)'})),
      /** 下一张图片 */
      state('next', style({'z-index': '2', 'transform': 'translateX(100%)'})),
      /** 当前图片 */
      state('on', style({'z-index': '3', 'transform': 'translateX(0)'})),
      transition('prev=>on', [
        animate('0.3s ease-in')
      ]),
      transition('next=>on', [
        animate('0.3s ease-in')
      ]),
      transition('on=>prev', [
        animate('0.3s ease-in')
      ]),
      transition('on=>next', [
        animate('0.3s ease-in')
      ])
    ])
  ]
})
export class SlideImgComponent implements OnInit{
  @Input() public imgs: string[];
  @Input() public current: number;
  @Output() public currentImg = new EventEmitter<any>();
  @Output() public click = new EventEmitter<any>();
  constructor() {
    this.current = 0;
  }
  public ImgState(index) {
    if (this.imgs && this.imgs.length) {
      if (this.current === 0) {
        return index === 0 ? 'on' :
          index === 1 ? 'next' :
            index === this.imgs.length - 1 ? 'prev' :
              'off';
      } else if (this.current === this.imgs.length - 1) {
        return index === this.imgs.length - 1 ? 'on' :
          index === this.imgs.length - 2 ? 'prev' :
            index === 0 ? 'next' :
              'off';
      }
      switch (index - this.current) {
        case 0:
          return 'on';
        case 1:
          return 'next';
        case -1:
          return 'prev';
        default:
          return 'off';
      }
    } else {
      return 'off';
    }
  }
  public Onclick(img,index){
    let params = {
      url: img,
      index: index
    };
    this.click.emit(params);
  }
  public next(event: Event) {
    this.current = (this.current + 1) % this.imgs.length;
    this.currentImg.emit(this.current);
    event.stopPropagation();
    return false;
  }
  public prev(event: Event) {

    this.current = this.current - 1 < 0 ? this.imgs.length - 1 : this.current - 1;
    this.currentImg.emit(this.current);
    event.stopPropagation();
    return false;
  }
  ngOnInit() { }
}

export class SlideImg {
  url: string;
}
