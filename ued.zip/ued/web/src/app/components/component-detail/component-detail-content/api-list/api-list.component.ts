import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Subject} from "rxjs/Subject";
import 'rxjs';
import {ApiListService} from "./service/post-list.service";
import {Api} from "../../../model/api-model";

@Component({
  selector: 'app-api-list',
  templateUrl: './api-list.component.html',
  styleUrls: ['./api-list.component.scss']
})
export class ApiListComponent implements OnInit {
  apiMap: any;
  search: string;
  search$ = new Subject<string>();
  firstReqReady: boolean = false; //防止初始加载时先渲染 “没有搜索到任何API"节点元素

  constructor(private route: ActivatedRoute,
              private router: Router,
              private apiListService: ApiListService) {
  }

  ngOnInit() {
    this.loadData();
    this.searchData();
  }

  doSearch(searchVal: string): void {
    this.search$.next(searchVal);
  }

  public searchData() {
    this.search$
      .debounceTime(200)
      .distinctUntilChanged()
      .switchMap(searchVal => this.apiListService.getApiList(searchVal))
      .subscribe(
        res => {
          this.apiMap = res;
        },
        error => {
          throw error
        }
      );
  }

  public loadData() {
    this.apiListService.getApiList()
      .subscribe(
        res => {
          this.apiMap = res;
          this.firstReqReady = true;
        },
        error => {
          throw error
        }
      );
  }

  showApiDetail(api: Api) {
    this.router.navigate([api.category, api.type], {relativeTo: this.route.parent});
  }
}
