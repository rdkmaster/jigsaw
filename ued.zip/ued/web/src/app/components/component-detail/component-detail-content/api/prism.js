/* http://prismjs.com/download.html?themes=prism-okaidia&languages=markup+css+clike+javascript+json+markdown+typescript&plugins=line-highlight+line-numbers */
var _self = "undefined" != typeof window ? window : "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope ? self : {}, Prism = function () {
  var e = /\blang(?:uage)?-(\w+)\b/i, t = 0, n = _self.Prism = {
    manual: _self.Prism && _self.Prism.manual,
    util: {
      encode: function (e) {
        return e instanceof a ? new a(e.type, n.util.encode(e.content), e.alias) : "Array" === n.util.type(e) ? e.map(n.util.encode) : e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ")
      }, type: function (e) {
        return Object.prototype.toString.call(e).match(/\[object (\w+)\]/)[1]
      }, objId: function (e) {
        return e.__id || Object.defineProperty(e, "__id", {value: ++t}), e.__id
      }, clone: function (e) {
        var t = n.util.type(e);
        switch (t) {
          case"Object":
            var a = {};
            for (var r in e)e.hasOwnProperty(r) && (a[r] = n.util.clone(e[r]));
            return a;
          case"Array":
            return e.map && e.map(function (e) {
                return n.util.clone(e)
              })
        }
        return e
      }
    },
    languages: {
      extend: function (e, t) {
        var a = n.util.clone(n.languages[e]);
        for (var r in t)a[r] = t[r];
        return a
      }, insertBefore: function (e, t, a, r) {
        r = r || n.languages;
        var l = r[e];
        if (2 == arguments.length) {
          a = arguments[1];
          for (var i in a)a.hasOwnProperty(i) && (l[i] = a[i]);
          return l
        }
        var o = {};
        for (var s in l)if (l.hasOwnProperty(s)) {
          if (s == t)for (var i in a)a.hasOwnProperty(i) && (o[i] = a[i]);
          o[s] = l[s]
        }
        return n.languages.DFS(n.languages, function (t, n) {
          n === r[e] && t != e && (this[t] = o)
        }), r[e] = o
      }, DFS: function (e, t, a, r) {
        r = r || {};
        for (var l in e)e.hasOwnProperty(l) && (t.call(e, l, e[l], a || l), "Object" !== n.util.type(e[l]) || r[n.util.objId(e[l])] ? "Array" !== n.util.type(e[l]) || r[n.util.objId(e[l])] || (r[n.util.objId(e[l])] = !0, n.languages.DFS(e[l], t, l, r)) : (r[n.util.objId(e[l])] = !0, n.languages.DFS(e[l], t, null, r)))
      }
    },
    plugins: {},
    highlightAll: function (e, t) {
      var a = {
        callback: t,
        selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
      };
      n.hooks.run("before-highlightall", a);
      for (var r, l = a.elements || document.querySelectorAll(a.selector), i = 0; r = l[i++];)n.highlightElement(r, e === !0, a.callback)
    },
    highlightElement: function (t, a, r) {
      for (var l, i, o = t; o && !e.test(o.className);)o = o.parentNode;
      o && (l = (o.className.match(e) || [, ""])[1].toLowerCase(), i = n.languages[l]), t.className = t.className.replace(e, "").replace(/\s+/g, " ") + " language-" + l, o = t.parentNode, /pre/i.test(o.nodeName) && (o.className = o.className.replace(e, "").replace(/\s+/g, " ") + " language-" + l);
      var s = t.textContent, u = {element: t, language: l, grammar: i, code: s};
      if (n.hooks.run("before-sanity-check", u), !u.code || !u.grammar)return u.code && (u.element.textContent = u.code), n.hooks.run("complete", u), void 0;
      if (n.hooks.run("before-highlight", u), a && _self.Worker) {
        var g = new Worker(n.filename);
        g.onmessage = function (e) {
          u.highlightedCode = e.data, n.hooks.run("before-insert", u), u.element.innerHTML = u.highlightedCode, r && r.call(u.element), n.hooks.run("after-highlight", u), n.hooks.run("complete", u)
        }, g.postMessage(JSON.stringify({language: u.language, code: u.code, immediateClose: !0}))
      } else u.highlightedCode = n.highlight(u.code, u.grammar, u.language), n.hooks.run("before-insert", u), u.element.innerHTML = u.highlightedCode, r && r.call(t), n.hooks.run("after-highlight", u), n.hooks.run("complete", u)
    },
    highlight: function (e, t, r) {
      var l = n.tokenize(e, t);
      return a.stringify(n.util.encode(l), r)
    },
    tokenize: function (e, t) {
      var a = n.Token, r = [e], l = t.rest;
      if (l) {
        for (var i in l)t[i] = l[i];
        delete t.rest
      }
      e:for (var i in t)if (t.hasOwnProperty(i) && t[i]) {
        var o = t[i];
        o = "Array" === n.util.type(o) ? o : [o];
        for (var s = 0; s < o.length; ++s) {
          var u = o[s], g = u.inside, c = !!u.lookbehind, h = !!u.greedy, f = 0, d = u.alias;
          if (h && !u.pattern.global) {
            var p = u.pattern.toString().match(/[imuy]*$/)[0];
            u.pattern = RegExp(u.pattern.source, p + "g")
          }
          u = u.pattern || u;
          for (var m = 0, y = 0; m < r.length; y += r[m].length, ++m) {
            var v = r[m];
            if (r.length > e.length)break e;
            if (!(v instanceof a)) {
              u.lastIndex = 0;
              var b = u.exec(v), k = 1;
              if (!b && h && m != r.length - 1) {
                if (u.lastIndex = y, b = u.exec(e), !b)break;
                for (var w = b.index + (c ? b[1].length : 0), _ = b.index + b[0].length, P = m, A = y, j = r.length; j > P && _ > A; ++P)A += r[P].length, w >= A && (++m, y = A);
                if (r[m] instanceof a || r[P - 1].greedy)continue;
                k = P - m, v = e.slice(y, A), b.index -= y
              }
              if (b) {
                c && (f = b[1].length);
                var w = b.index + f, b = b[0].slice(f), _ = w + b.length, x = v.slice(0, w), O = v.slice(_), S = [m, k];
                x && S.push(x);
                var N = new a(i, g ? n.tokenize(b, g) : b, d, b, h);
                S.push(N), O && S.push(O), Array.prototype.splice.apply(r, S)
              }
            }
          }
        }
      }
      return r
    },
    hooks: {
      all: {}, add: function (e, t) {
        var a = n.hooks.all;
        a[e] = a[e] || [], a[e].push(t)
      }, run: function (e, t) {
        var a = n.hooks.all[e];
        if (a && a.length)for (var r, l = 0; r = a[l++];)r(t)
      }
    }
  }, a = n.Token = function (e, t, n, a, r) {
    this.type = e, this.content = t, this.alias = n, this.length = 0 | (a || "").length, this.greedy = !!r
  };
  if (a.stringify = function (e, t, r) {
      if ("string" == typeof e)return e;
      if ("Array" === n.util.type(e))return e.map(function (n) {
        return a.stringify(n, t, e)
      }).join("");
      var l = {
        type: e.type,
        content: a.stringify(e.content, t, r),
        tag: "span",
        classes: ["token", e.type],
        attributes: {},
        language: t,
        parent: r
      };
      if ("comment" == l.type && (l.attributes.spellcheck = "true"), e.alias) {
        var i = "Array" === n.util.type(e.alias) ? e.alias : [e.alias];
        Array.prototype.push.apply(l.classes, i)
      }
      n.hooks.run("wrap", l);
      var o = Object.keys(l.attributes).map(function (e) {
        return e + '="' + (l.attributes[e] || "").replace(/"/g, "&quot;") + '"'
      }).join(" ");
      return "<" + l.tag + ' class="' + l.classes.join(" ") + '"' + (o ? " " + o : "") + ">" + l.content + "</" + l.tag + ">"
    }, !_self.document)return _self.addEventListener ? (_self.addEventListener("message", function (e) {
    var t = JSON.parse(e.data), a = t.language, r = t.code, l = t.immediateClose;
    _self.postMessage(n.highlight(r, n.languages[a], a)), l && _self.close()
  }, !1), _self.Prism) : _self.Prism;
  var r = document.currentScript || [].slice.call(document.getElementsByTagName("script")).pop();
  return r && (n.filename = r.src, !document.addEventListener || n.manual || r.hasAttribute("data-manual") || ("loading" !== document.readyState ? window.requestAnimationFrame ? window.requestAnimationFrame(n.highlightAll) : window.setTimeout(n.highlightAll, 16) : document.addEventListener("DOMContentLoaded", n.highlightAll))), _self.Prism
}();
"undefined" != typeof module && module.exports && (module.exports = Prism), "undefined" != typeof global && (global.Prism = Prism);
Prism.languages.markup = {
  comment: /<!--[\w\W]*?-->/,
  prolog: /<\?[\w\W]+?\?>/,
  doctype: /<!DOCTYPE[\w\W]+?>/i,
  cdata: /<!\[CDATA\[[\w\W]*?]]>/i,
  tag: {
    pattern: /<\/?(?!\d)[^\s>\/=$<]+(?:\s+[^\s>\/=]+(?:=(?:("|')(?:\\\1|\\?(?!\1)[\w\W])*\1|[^\s'">=]+))?)*\s*\/?>/i,
    inside: {
      tag: {pattern: /^<\/?[^\s>\/]+/i, inside: {punctuation: /^<\/?/, namespace: /^[^\s>\/:]+:/}},
      "attr-value": {pattern: /=(?:('|")[\w\W]*?(\1)|[^\s>]+)/i, inside: {punctuation: /[=>"']/}},
      punctuation: /\/?>/,
      "attr-name": {pattern: /[^\s>\/]+/, inside: {namespace: /^[^\s>\/:]+:/}}
    }
  },
  entity: /&#?[\da-z]{1,8};/i
}, Prism.hooks.add("wrap", function (a) {
  "entity" === a.type && (a.attributes.title = a.content.replace(/&amp;/, "&"))
}), Prism.languages.xml = Prism.languages.markup, Prism.languages.html = Prism.languages.markup, Prism.languages.mathml = Prism.languages.markup, Prism.languages.svg = Prism.languages.markup;
Prism.languages.css = {
  comment: /\/\*[\w\W]*?\*\//,
  atrule: {pattern: /@[\w-]+?.*?(;|(?=\s*\{))/i, inside: {rule: /@[\w-]+/}},
  url: /url\((?:(["'])(\\(?:\r\n|[\w\W])|(?!\1)[^\\\r\n])*\1|.*?)\)/i,
  selector: /[^\{\}\s][^\{\};]*?(?=\s*\{)/,
  string: {pattern: /("|')(\\(?:\r\n|[\w\W])|(?!\1)[^\\\r\n])*\1/, greedy: !0},
  property: /(\b|\B)[\w-]+(?=\s*:)/i,
  important: /\B!important\b/i,
  "function": /[-a-z0-9]+(?=\()/i,
  punctuation: /[(){};:]/
}, Prism.languages.css.atrule.inside.rest = Prism.util.clone(Prism.languages.css), Prism.languages.markup && (Prism.languages.insertBefore("markup", "tag", {
  style: {
    pattern: /(<style[\w\W]*?>)[\w\W]*?(?=<\/style>)/i,
    lookbehind: !0,
    inside: Prism.languages.css,
    alias: "language-css"
  }
}), Prism.languages.insertBefore("inside", "attr-value", {
  "style-attr": {
    pattern: /\s*style=("|').*?\1/i,
    inside: {
      "attr-name": {pattern: /^\s*style/i, inside: Prism.languages.markup.tag.inside},
      punctuation: /^\s*=\s*['"]|['"]\s*$/,
      "attr-value": {pattern: /.+/i, inside: Prism.languages.css}
    },
    alias: "language-css"
  }
}, Prism.languages.markup.tag));
Prism.languages.clike = {
  comment: [{pattern: /(^|[^\\])\/\*[\w\W]*?\*\//, lookbehind: !0}, {
    pattern: /(^|[^\\:])\/\/.*/,
    lookbehind: !0
  }],
  string: {pattern: /(["'])(\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/, greedy: !0},
  "class-name": {
    pattern: /((?:\b(?:class|interface|extends|implements|trait|instanceof|new)\s+)|(?:catch\s+\())[a-z0-9_\.\\]+/i,
    lookbehind: !0,
    inside: {punctuation: /(\.|\\)/}
  },
  keyword: /\b(if|else|while|do|for|return|in|instanceof|function|new|try|throw|catch|finally|null|break|continue)\b/,
  "boolean": /\b(true|false)\b/,
  "function": /[a-z0-9_]+(?=\()/i,
  number: /\b-?(?:0x[\da-f]+|\d*\.?\d+(?:e[+-]?\d+)?)\b/i,
  operator: /--?|\+\+?|!=?=?|<=?|>=?|==?=?|&&?|\|\|?|\?|\*|\/|~|\^|%/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.javascript = Prism.languages.extend("clike", {
  keyword: /\b(as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|var|void|while|with|yield)\b/,
  number: /\b-?(0x[\dA-Fa-f]+|0b[01]+|0o[0-7]+|\d*\.?\d+([Ee][+-]?\d+)?|NaN|Infinity)\b/,
  "function": /[_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*(?=\()/i,
  operator: /--?|\+\+?|!=?=?|<=?|>=?|==?=?|&&?|\|\|?|\?|\*\*?|\/|~|\^|%|\.{3}/
}), Prism.languages.insertBefore("javascript", "keyword", {
  regex: {
    pattern: /(^|[^\/])\/(?!\/)(\[.+?]|\\.|[^\/\\\r\n])+\/[gimyu]{0,5}(?=\s*($|[\r\n,.;})]))/,
    lookbehind: !0,
    greedy: !0
  }
}), Prism.languages.insertBefore("javascript", "string", {
  "template-string": {
    pattern: /`(?:\\\\|\\?[^\\])*?`/,
    greedy: !0,
    inside: {
      interpolation: {
        pattern: /\$\{[^}]+\}/,
        inside: {
          "interpolation-punctuation": {pattern: /^\$\{|\}$/, alias: "punctuation"},
          rest: Prism.languages.javascript
        }
      }, string: /[\s\S]+/
    }
  }
}), Prism.languages.markup && Prism.languages.insertBefore("markup", "tag", {
  script: {
    pattern: /(<script[\w\W]*?>)[\w\W]*?(?=<\/script>)/i,
    lookbehind: !0,
    inside: Prism.languages.javascript,
    alias: "language-javascript"
  }
}), Prism.languages.js = Prism.languages.javascript;
Prism.languages.json = {
  property: /"(?:\\.|[^\\"])*"(?=\s*:)/gi,
  string: /"(?!:)(?:\\.|[^\\"])*"(?!:)/g,
  number: /\b-?(0x[\dA-Fa-f]+|\d*\.?\d+([Ee][+-]?\d+)?)\b/g,
  punctuation: /[{}[\]);,]/g,
  operator: /:/g,
  "boolean": /\b(true|false)\b/gi,
  "null": /\bnull\b/gi
}, Prism.languages.jsonp = Prism.languages.json;
Prism.languages.markdown = Prism.languages.extend("markup", {}), Prism.languages.insertBefore("markdown", "prolog", {
  blockquote: {
    pattern: /^>(?:[\t ]*>)*/m,
    alias: "punctuation"
  },
  code: [{pattern: /^(?: {4}|\t).+/m, alias: "keyword"}, {pattern: /``.+?``|`[^`\n]+`/, alias: "keyword"}],
  title: [{
    pattern: /\w+.*(?:\r?\n|\r)(?:==+|--+)/,
    alias: "important",
    inside: {punctuation: /==+$|--+$/}
  }, {pattern: /(^\s*)#+.+/m, lookbehind: !0, alias: "important", inside: {punctuation: /^#+|#+$/}}],
  hr: {pattern: /(^\s*)([*-])([\t ]*\2){2,}(?=\s*$)/m, lookbehind: !0, alias: "punctuation"},
  list: {pattern: /(^\s*)(?:[*+-]|\d+\.)(?=[\t ].)/m, lookbehind: !0, alias: "punctuation"},
  "url-reference": {
    pattern: /!?\[[^\]]+\]:[\t ]+(?:\S+|<(?:\\.|[^>\\])+>)(?:[\t ]+(?:"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\((?:\\.|[^)\\])*\)))?/,
    inside: {
      variable: {pattern: /^(!?\[)[^\]]+/, lookbehind: !0},
      string: /(?:"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\((?:\\.|[^)\\])*\))$/,
      punctuation: /^[\[\]!:]|[<>]/
    },
    alias: "url"
  },
  bold: {
    pattern: /(^|[^\\])(\*\*|__)(?:(?:\r?\n|\r)(?!\r?\n|\r)|.)+?\2/,
    lookbehind: !0,
    inside: {punctuation: /^\*\*|^__|\*\*$|__$/}
  },
  italic: {
    pattern: /(^|[^\\])([*_])(?:(?:\r?\n|\r)(?!\r?\n|\r)|.)+?\2/,
    lookbehind: !0,
    inside: {punctuation: /^[*_]|[*_]$/}
  },
  url: {
    pattern: /!?\[[^\]]+\](?:\([^\s)]+(?:[\t ]+"(?:\\.|[^"\\])*")?\)| ?\[[^\]\n]*\])/,
    inside: {variable: {pattern: /(!?\[)[^\]]+(?=\]$)/, lookbehind: !0}, string: {pattern: /"(?:\\.|[^"\\])*"(?=\)$)/}}
  }
}), Prism.languages.markdown.bold.inside.url = Prism.util.clone(Prism.languages.markdown.url), Prism.languages.markdown.italic.inside.url = Prism.util.clone(Prism.languages.markdown.url), Prism.languages.markdown.bold.inside.italic = Prism.util.clone(Prism.languages.markdown.italic), Prism.languages.markdown.italic.inside.bold = Prism.util.clone(Prism.languages.markdown.bold);
Prism.languages.typescript = Prism.languages.extend("javascript", {keyword: /\b(as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|var|void|while|with|yield|false|true|module|declare|constructor|string|Function|any|number|boolean|Array|enum|symbol|namespace|abstract|require|type)\b/}), Prism.languages.ts = Prism.languages.typescript;
!function () {
  function e(e, t) {
    return Array.prototype.slice.call((t || document).querySelectorAll(e))
  }

  function t(e, t) {
    return t = " " + t + " ", (" " + e.className + " ").replace(/[\n\t]/g, " ").indexOf(t) > -1
  }

  function n(e, n, i) {
    for (var o, a = n.replace(/\s+/g, "").split(","), d = +e.getAttribute("data-line-offset") || 0, l = r() ? parseInt : parseFloat, c = l(getComputedStyle(e).lineHeight), s = 0; o = a[s++];) {
      o = o.split("-");
      var u = +o[0], m = +o[1] || u, h = document.createElement("div");
      h.textContent = Array(m - u + 2).join(" \n"), h.setAttribute("aria-hidden", "true"), h.className = (i || "") + " line-highlight", t(e, "line-numbers") || (h.setAttribute("data-start", u), m > u && h.setAttribute("data-end", m)), h.style.top = (u - d - 1) * c + "px", t(e, "line-numbers") ? e.appendChild(h) : (e.querySelector("code") || e).appendChild(h)
    }
  }

  function i() {
    var t = location.hash.slice(1);
    e(".temporary.line-highlight").forEach(function (e) {
      e.parentNode.removeChild(e)
    });
    var i = (t.match(/\.([\d,-]+)$/) || [, ""])[1];
    if (i && !document.getElementById(t)) {
      var r = t.slice(0, t.lastIndexOf(".")), o = document.getElementById(r);
      o && (o.hasAttribute("data-line") || o.setAttribute("data-line", ""), n(o, i, "temporary "), document.querySelector(".temporary.line-highlight").scrollIntoView())
    }
  }

  if ("undefined" != typeof self && self.Prism && self.document && document.querySelector) {
    var r = function () {
      var e;
      return function () {
        if ("undefined" == typeof e) {
          var t = document.createElement("div");
          t.style.fontSize = "13px", t.style.lineHeight = "1.5", t.style.padding = 0, t.style.border = 0, t.innerHTML = "&nbsp;<br />&nbsp;", document.body.appendChild(t), e = 38 === t.offsetHeight, document.body.removeChild(t)
        }
        return e
      }
    }(), o = 0;
    Prism.hooks.add("before-sanity-check", function (t) {
      var n = t.element.parentNode, i = n && n.getAttribute("data-line");
      if (n && i && /pre/i.test(n.nodeName)) {
        var r = 0;
        e(".line-highlight", n).forEach(function (e) {
          r += e.textContent.length, e.parentNode.removeChild(e)
        }), r && /^( \n)+$/.test(t.code.slice(-r)) && (t.code = t.code.slice(0, -r))
      }
    }), Prism.hooks.add("complete", function (e) {
      var t = e.element.parentNode, r = t && t.getAttribute("data-line");
      t && r && /pre/i.test(t.nodeName) && (clearTimeout(o), n(t, r), o = setTimeout(i, 1))
    }), window.addEventListener && window.addEventListener("hashchange", i)
  }
}();
!function () {
  "undefined" != typeof self && self.Prism && self.document && Prism.hooks.add("complete", function (e) {
    if (e.code) {
      var t = e.element.parentNode, s = /\s*\bline-numbers\b\s*/;
      if (t && /pre/i.test(t.nodeName) && (s.test(t.className) || s.test(e.element.className)) && !e.element.querySelector(".line-numbers-rows")) {
        s.test(e.element.className) && (e.element.className = e.element.className.replace(s, "")), s.test(t.className) || (t.className += " line-numbers");
        var n, a = e.code.match(/\n(?!$)/g), l = a ? a.length + 1 : 1, r = new Array(l + 1);
        r = r.join("<span></span>"), n = document.createElement("span"), n.setAttribute("aria-hidden", "true"), n.className = "line-numbers-rows", n.innerHTML = r, t.hasAttribute("data-start") && (t.style.counterReset = "linenumber " + (parseInt(t.getAttribute("data-start"), 10) - 1)), e.element.appendChild(n)
      }
    }
  })
}();
