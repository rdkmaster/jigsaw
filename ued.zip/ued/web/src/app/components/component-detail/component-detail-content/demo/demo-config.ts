export class Demo {
  desc: string;
  url: string;
}
