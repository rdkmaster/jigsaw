/**
 * Created by 6396000843 on 2017/9/7.
 */

export class Api {
  id: number;
  type: string;
  category:string
}
