import { Component, OnInit } from '@angular/core';
import { NgModule } from '@angular/core';

import { ComponentMenuNav } from "../../../model/menu-nav-model";
import { Router, ActivatedRoute, Params ,NavigationExtras} from '@angular/router';
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";
import { Http } from '@angular/http';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/filter';
import {ComponentMenuService} from "../../../service/component.service";
import {ApiListService} from "./service/post-list.service";
import {Api} from "../../../model/api-model";

@Component({
  selector: 'app-api-list',
  templateUrl: './api-list.component.html',
  styleUrls: ['./api-list.component.scss']
})
export class ApiListComponent implements OnInit {
  componentMenuNav: ComponentMenuNav;
  apiMap:any;
  search:string;
  search$ = new Subject<string>();
  firstReqReady:boolean=false; //防止初始加载时先渲染 “没有搜索到任何API"节点元素


  constructor(
    private componentService:ComponentMenuService,
    private route: ActivatedRoute,
    private router: Router,
    private apiListService:ApiListService,
    private http:Http
  ) { }

  ngOnInit() {
    //this.apiList=["AbstractDialogComponentBase","AbstractGeneralCollection"];
    this.route.parent.params
      .subscribe((params: Params) =>{
        this.componentMenuNav = this.componentService.getComponentMenuNav(params['name']);
        this.loadData(this.componentMenuNav.name);
      });

    this.searchData();
  }

  doSearch(searchVal: string): void {
    this.search$.next(searchVal);
  }

  public searchData(){
    this.search$
      //.filter((searchVal: string) => searchVal.length > 1)
      .debounceTime(200)
      .distinctUntilChanged()
      .switchMap(searchVal=>{
        return this.apiListService.getApiList(searchVal)
      })
      .subscribe(
        res=>{
          this.apiMap=res;
        },
        error => {throw error}
      );
  }

  public loadData(menuName:string){
    this.apiListService.getApiList()
      .subscribe(
        res=>{
          this.apiMap=res;
          this.firstReqReady=true;
        },
        error => {throw error},
        () => {}
      );
  }

  gotoApiDetail(api:Api){
    let navigationExtras: NavigationExtras = {
      queryParams: { 'apiItem': api.name,'parentName': api.parentName},
      relativeTo: this.route
    };
    this.router.navigate([`../api`], navigationExtras);
  }
}
