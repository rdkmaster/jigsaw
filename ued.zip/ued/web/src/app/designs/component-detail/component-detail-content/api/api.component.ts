import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';
import {ComponentMenuNav} from "../../../model/menu-nav-model"
import {ComponentMenuService} from "../../../service/component.service";
import {Http} from '@angular/http';
import {Observable} from "rxjs/Observable";
import 'rxjs/add/operator/switchMap';
import 'rxjs';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/filter';

@Component({
  selector: 'app-api',
  templateUrl: './api.component.html',
  styleUrls: ['../../../../common/jigsaw-markdown/jigsaw-markdown.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ApiComponent implements OnInit {
  componentMenuNav: ComponentMenuNav;
  apiContent: string = 'Loading...';
  apiDetailFile: string;

  constructor(private componentService: ComponentMenuService,
              private route: ActivatedRoute,
              private http: Http) {
  }

  ngOnInit() {
    this.route.parent.params
      .switchMap(this.getApiContent.bind(this))
      .subscribe((html: string) => {
        this.apiContent = html;

        setTimeout(() => {
          const $anchor = $(`[name="${location.hash.substring(1)}"]`);
          if ($anchor.length > 0) {
            this.componentService.perfectScrollbar.scrollToY($anchor.offset().top - 64, 10);
          }
        }, 200);
      });
  }

  private getApiContent(params: Params): Observable<any> {
    let apiUrl = ``;
    let protectHtml = ``;
    this.componentMenuNav = this.componentService.getComponentMenuNav(params['name']);
    if (this.componentMenuNav.parentLabel == "资源") {
      let apiParentName: string = "";
      this.route.queryParams
      //.map(params => params["apiItem"])
        .subscribe(queryParams => {
          this.apiDetailFile = queryParams["apiItem"];
          apiParentName = queryParams["parentName"] || params['name'];
        });
      apiUrl = `/jigsaw/doc/fragments/${apiParentName}/${this.apiDetailFile}.html`;
      protectHtml = `<h1>Sorry! Jigsaw 找不到${this.apiDetailFile}文档！！</h1>`;
    } else if (this.componentMenuNav.parentLabel == "服务") {
      let apiFileName = this.transformService(this.componentMenuNav.name);
      let apiType = this.componentService.apiTypeMap(this.componentMenuNav.name);
      apiUrl = `/jigsaw/doc/fragments/${apiType}/${apiFileName}.html`;
      protectHtml = `<div><img src="doc/ued-design/img/UED-developing.png" alt=""></div>`;
    }
    else {
      let apiFileName = this.transformJigsaw(this.componentMenuNav.name);
      let apiType = "component";
      apiFileName = this.componentService.apiNameMap(this.componentMenuNav.name);
      apiUrl = `/jigsaw/doc/fragments/${apiType}/${apiFileName}.html`;
      protectHtml = `<div><img src="doc/ued-design/img/UED-developing.png" alt=""></div>`;
    }
    return this.http.get(apiUrl)
      .map(html => this.fixAnchorHref(html.text()))
      .catch(err => {
        console.error("jigsaw 找不到这个文档！！");
        return Observable.create(subscriber => {
            subscriber.next(protectHtml);
            subscriber.complete()
          }
        )
      })
  }

  //修复html文档内部导航定位地址
  private fixAnchorHref(html: string): string {
    return html.replace(/<a\b([^>]*)\s+href="#([^"]+)"/g, `<a$1 href="${location.pathname}#$2"`);
  }

  private transformJigsaw(apiFileName: string): string {
    return "Jigsaw" + apiFileName.replace(/( |^|-)([a-z])/g, (found, prefix, char) => char.toUpperCase());
  }

  //为服务类的文档拼URL
  private transformService(apiFileName: string): string {
    return apiFileName.replace(/( |^|-)([a-z])/g, (found, prefix, char) => char.toUpperCase()) + "Service";
  }

  private getApiType(apiFileName: string): string {
    switch (apiFileName) {
      case "JigsawTooltip":
        return "directive";
      default:
        return "component"
    }
  }
}
