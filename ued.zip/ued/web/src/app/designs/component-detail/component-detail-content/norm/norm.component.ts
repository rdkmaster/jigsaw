import { Component, OnInit } from '@angular/core';

import {ComponentMenuNav} from "../../../model/menu-nav-model";
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ComponentMenuService} from "../../../service/component.service";
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
@Component({
  selector: 'app-norm',
  templateUrl: './norm.component.html',
  styleUrls: ['./norm.component.css']
})
export class NormComponent implements OnInit {
  componentMenuNav:ComponentMenuNav;
  mdUrl:string;
  constructor(
    private componentService:ComponentMenuService,
    private route: ActivatedRoute,
    private router: Router,
  ) { }

  ngOnInit() {
    this.route.parent.params
      .subscribe((params: Params) => {
        this.componentMenuNav = this.componentService.getComponentMenuNav(params['name']);
        this.mdUrl=this.transformNormDesign(this.componentMenuNav);
      });
  }

  private transformNormDesign(componentMenuNav:ComponentMenuNav):string{
    // return "Jigsaw" + str.slice(0, 1).toUpperCase() + str.slice(1);
    let strComponentMenuNav = JSON.stringify(componentMenuNav);

    let name: string = /^\/designs\//.test(this.router.url)?"designs":"components"

    return encodeURI(`rdk/service/app/ued/server/${name}/norm?name=${strComponentMenuNav}`);
  }
}
