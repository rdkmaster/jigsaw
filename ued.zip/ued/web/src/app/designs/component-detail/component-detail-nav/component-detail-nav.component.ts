import 'rxjs/add/operator/switchMap'; //这里导入switchMap操作符是因为我们稍后将会处理路由参数的可观察对象Observable。
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ComponentMenuService } from "../../service/component.service";
import { ComponentMenuNav } from "../../model/menu-nav-model"

@Component({
  selector: 'app-component-detail-nav',
  templateUrl: './component-detail-nav.component.html',
  styleUrls: ['./component-detail-nav.component.scss']
})
export class ComponentDetailNavComponent implements OnInit {

  componentMenuNav: ComponentMenuNav;
  detailNavList:DetailNav[];
  showNav:boolean = true;
  constructor(
    public componentService:ComponentMenuService,
    private route: ActivatedRoute,
    private router: Router
  ) {}
  ngOnInit() {
    this.route.params
      .subscribe((params: Params) => {
        this.componentMenuNav =  this.componentService.getComponentMenuNav(params['name']);
        this.showNav = this.componentService.isApiDemoComponent(this.componentMenuNav.name);
        this.detailNavList = NAV_LIST.filter((nav:DetailNav)=>{
          return this.componentMenuNav.content.indexOf(nav.id)!=-1
        })
      });
  }

  recordLastNav(navName:string){
    this.router.navigate([navName], { relativeTo: this.route });
    this.componentService.setLastDetailNav(navName);
  }

}

class DetailNav{
  constructor(public id:string,public label:string,public router:string){
    this.id=id;
    this.label=label;
    this.router=router;
  }
}
const NAV_LIST:DetailNav[]=[
  new DetailNav("A","API","api"),
  new DetailNav("D","示例","demo"),
];


