import 'rxjs/add/operator/switchMap'; //这里导入switchMap操作符是因为我们稍后将会处理路由参数的可观察对象Observable。
import {AfterViewChecked, Component, Inject, NgZone, OnInit, PLATFORM_ID, ViewChild} from '@angular/core';
import {ActivatedRoute, Params, Router} from '@angular/router';
import {ComponentMenuService} from "../service/component.service";
import {ComponentMenuNav} from "../model/menu-nav-model"
import {PerfectScrollbarDirective} from "ngx-perfect-scrollbar";

@Component({
  selector: 'app-component-detail',
  templateUrl: './component-detail.component.html',
  styleUrls: ['./component-detail.component.css']
})
export class ComponentDetailComponent implements OnInit,AfterViewChecked {

  componentMenuNav: ComponentMenuNav;
  isShowTemplate: boolean = false;

  @ViewChild(PerfectScrollbarDirective) directiveScroll: PerfectScrollbarDirective;
  constructor(
    private componentService:ComponentMenuService,
    private route: ActivatedRoute,
    private router: Router,
    private zone: NgZone
  ) {}

  ngOnInit(): void {
      if(/^\/components\//.test(this.router.url)){
        this.isShowTemplate=true;
      }
    this.componentService.perfectScrollbar = this.directiveScroll;
    //使用subscribe方法来检测id的变化，并据此重新获取英雄。
    this.route.params
      //.switchMap((params: Params) => this.componentService.getComponentMenuNav(params['name']))
      .subscribe((params: Params) => {
        this.componentService.setFirstVaule(params['name']);
        this.componentMenuNav = this.componentService.getComponentMenuNav(params['name']);

        //this.router.navigate(['norm'], { relativeTo: this.route })
      });
    //this.route.paramMap
    //  //.switchMap((params: Params) => this.componentService.getComponentMenuNav(params['name']))
    //  .subscribe((params: Params) => {
    //    this.componentMenuNav = this.componentService.getComponentMenuNav(params['name']);
    //    //this.router.navigate(['norm'], { relativeTo: this.route })
    //  });
   //.switchMap((params: Params) => this.service.getHero(+params['id']))

  }

  ngAfterViewChecked():void {
    this.zone.runOutsideAngular(()=>{
      this.directiveScroll.update();
    });
  }

}
