import {Component, OnInit, OnChanges, PLATFORM_ID, Inject, OnDestroy} from '@angular/core';
import {Router, ActivatedRoute, Params, ParamMap, NavigationEnd} from '@angular/router';
import {ComponentMenuService} from "../service/component.service";
import {ComponentMenuNav} from "../model/menu-nav-model"
import {isPlatformBrowser} from '@angular/common';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/filter';
import {fade} from "../../animations/fade";
// enableProdMode();


@Component({
  templateUrl: './component-menu-nav.component.html',
  styleUrls: ['./component-menu-nav.component.scss'],
  animations: [fade]
})
export class ComponentMenuNavComponent implements OnInit, OnChanges, OnDestroy {

  ComponentMenuNavItems: ComponentMenuNav[];
  lastRecordDetailNav: string = 'norm';
  startUp: boolean = false;
  comName: any;
  routerDestroy: any;
  startName: string;
  constructor(private componentService: ComponentMenuService,
              private route: ActivatedRoute,
              private router: Router,
              @Inject(PLATFORM_ID) private platformId: Object) {
  }

  ngOnInit() {
    // if (isPlatformBrowser(this.platformId)) {
    //   window.onpopstate = (event) => {
    //     if (/^\/components$/.test(window.location.pathname)) {
    //       this.componentService.setStartup(true);
    //     }
    //   };
    // }
    //选取左边栏第一个路由的值
    let data = this.route.snapshot.data.menuNavList;
    let sortFun = (a,b)=>{
      if(a.orderByNum>b.orderByNum){
        return 1;
      }
      if(a.orderByNum<b.orderByNum){
        return -1;
      }
      if(a.orderByNum==b.orderByNum){
        return 0;
      }
    };
    let firstMenu: any= data.filter(val=>{
      return val.parent === '0' || !val.parent;
    }).sort(sortFun)[0];
    let secondMenu: any= data.filter(val=>{
      return val.parent === firstMenu.menuId;
    }).sort(sortFun)[0];
    this.startName = secondMenu.name;


    this.loadMenuNav();
    this.componentService.getLastDetailNav()
      .subscribe((last: string) => this.lastRecordDetailNav = last);
    //1级导航
    this.comName = this.componentService.getStartup()
      .subscribe(res => {
        this.startUp = res;
      });
    // this.route.firstChild && this.route.firstChild.paramMap
    //   .subscribe((params: ParamMap) => {
    //     console.log(params.get('name'),"*********");
    //     let selectedMenu = this.componentService.getComponentMenuNav(params.get('name'));
    //     this.selectedMenuNavId = selectedMenu["menuId"];
    //     console.log(this.selectedMenuNavId)
    //   });
    this.componentService.getFirstVaule()
      .subscribe(res=>{
        let selectedMenu = this.componentService.getComponentMenuNav(res);
        this.selectedMenuNavId = selectedMenu["menuId"];
      })
    this.route.url.subscribe(res => {
      if (/^\/components$/.test(this.router.url)) {
        this.startUp = true;
      }
      if (/^\/designs$/.test(this.router.url)) {
        this.router.navigate([`${this.startName}/norm`],{ relativeTo: this.route });
        let selectedMenu = this.componentService.getComponentMenuNav(this.startName);
        this.selectedMenuNavId = selectedMenu["menuId"];
      }
    });
    this.routerDestroy=this.router.events
      .subscribe((event) => {
        if (event instanceof NavigationEnd) { // 当导航成功结束时执行
          if(event.url ==="/components"){
            this.componentService.setStartup(true)
            this.selectedMenuNavId = null;
          }else if(event.url ==="/designs"){
            this.router.navigate([`${this.startName}/norm`],{ relativeTo: this.route })
          }else{
            this.componentService.setStartup(false);
          }
        }
      });
  }

  ngOnChanges(): void {

  }

  selectedMenuNavId: number;

  loadMenuNav() {
    //resolver守卫中获取菜单:
    this.route.data
      .subscribe((data: { menuNavList: ComponentMenuNav[] }) => {
        this.ComponentMenuNavItems = data.menuNavList;
        this.componentService.menuNavList = data.menuNavList;
      });
  }

  isSelected(componentMenuNav): boolean {
    return componentMenuNav.menuId === this.selectedMenuNavId;
  }

  gotoComponentDetail(componentMenuNav: ComponentMenuNav) {
    this.selectedMenuNavId = componentMenuNav["menuId"];
    if(!this.componentService.isApiDemoComponent(componentMenuNav.name)){
      componentMenuNav.content = "T";//特殊的内容例如国际化i18n由norm组件展示
    }
    if (componentMenuNav.name.match(/jigsaw$/i)) {  // jigsaw路由特别处理显示所有API
      //this.router.navigate(['jigsaw/docs/quickstart'], {relativeTo: this.route});
      this.router.navigate([componentMenuNav.name, "api-list"], {relativeTo: this.route});
    } else {
      if (componentMenuNav.content != null && componentMenuNav.content.length) {
        let key = this._secondNav(this.lastRecordDetailNav);
        if (componentMenuNav.content.indexOf(key) == -1) {
          this.lastRecordDetailNav = this._secondNav(componentMenuNav.content.charAt(0))
        } else {
          if (componentMenuNav.content.indexOf("A") !== -1) {
            this.lastRecordDetailNav = this._secondNav("A")
          }
        }
      }
      this.router.navigate([componentMenuNav.name, this.lastRecordDetailNav], {relativeTo: this.route});
    }
  }

  send() {
    this.router.navigate([`/components/${this.startName}/norm`])
  }

  private _secondNav(content: string): string {
    switch (content) {
      case "T":
        return "norm";
      case "D":
        return "demo";
      case "A":
        return "api";
      case "norm":
        return "T";
      case "demo":
        return "D";
      case "api":
        return "A";
    }
  }

  ngOnDestroy(): void {
    // window.onpopstate = null;
    this.comName.unsubscribe();
    this.routerDestroy.unsubscribe();
  }
}
