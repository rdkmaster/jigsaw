"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var MenuFilterPipe = (function () {
    function MenuFilterPipe() {
    }
    MenuFilterPipe.prototype.transform = function (value, level, parent) {
        var result = [];
        if (typeof value == "undefined" || !value) {
            return;
        }
        if (typeof parent == "undefined") {
            //return value.map(item => {
            //  if(item.level==level){
            //    return result.push(item)
            //  }
            //});
            for (var _i = 0, value_1 = value; _i < value_1.length; _i++) {
                var item = value_1[_i];
                if (item.level == level) {
                    result.push(item);
                }
            }
            return result;
        }
        for (var _a = 0, value_2 = value; _a < value_2.length; _a++) {
            var item = value_2[_a];
            if (item.level == level && item.parent == parent) {
                result.push(item);
            }
        }
        return result;
    };
    MenuFilterPipe = __decorate([
        core_1.Pipe({
            name: 'menuFilter'
        })
    ], MenuFilterPipe);
    return MenuFilterPipe;
}());
exports.MenuFilterPipe = MenuFilterPipe;
