import { NgModule } from '@angular/core';
import {Router, RouterModule, Routes} from '@angular/router';
import {ComponentDetailComponent} from "./component-detail/component-detail.component";
import {ComponentMenuNavComponent} from "./component-menu-nav/component-menu-nav.component";
import {ComponentDetailContentComponent} from "./component-detail/component-detail-content/component-detail-content.component";
import {MenuNavResolver} from "./service/menu-nav-resolver.service";
import {AppAnalysisService} from "../app.analysis.service";


const ComponentRoutes: Routes = [
  {
    path: '',  component: ComponentMenuNavComponent,
    children:[
      {
        path: ':name', component: ComponentDetailComponent,
        children:[
          { path:'', redirectTo: 'norm', pathMatch:'full'},
          {path: ':navName',  component: ComponentDetailContentComponent},
          {path: ':navName/:apiItem', redirectTo:'api', pathMatch:'full'},
        ]
      }
    ],
    resolve: {
      menuNavList: MenuNavResolver
    }
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(ComponentRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    MenuNavResolver, AppAnalysisService
  ]
})
export class ComponentRoutingModule {
  constructor(analysis: AppAnalysisService, router: Router) {
    analysis.addRouterListener(router);
  }
}
