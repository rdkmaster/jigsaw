/**
 * Created by 6396000843 on 2017/8/17.
 */

export class ComponentMenuNav {
  menuId: number;
  name: string;
  label: string;
  level:number;
  parent:number;
  orderByNum:number;
  parentLabel:string;
  parentOrder:number;
  content:string;
}



