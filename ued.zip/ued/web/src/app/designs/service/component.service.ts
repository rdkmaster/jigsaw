/**
 * Created by 6396000843 on 2017/7/24.
 */
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http, Headers, Response,RequestOptions, Request, RequestMethod } from '@angular/http';
import { Subject } from 'rxjs/Subject';

import { ComponentMenuNav } from "../model/menu-nav-model"
import {PerfectScrollbarDirective} from "ngx-perfect-scrollbar";

@Injectable()
export class ComponentMenuService {

  constructor(private http:Http) {
  }

  menuNavList:ComponentMenuNav[] = [];
  showNormComponentList = ["i18n"];

  menuNavUrl:string="rdk/service/app/ued/server/components/menu-nav";
  dMenuNavUrl:string="rdk/service/app/ued/server/designs/menu-nav";

  getComponentMenuNavList():Observable<ComponentMenuNav[]>{
    return this.http
      .get(this.menuNavUrl)
      .map(res => {return res.json()})
  }
  getDesignMenuNavList():Observable<ComponentMenuNav[]>{
    return this.http
      .get(this.dMenuNavUrl)
      .map(res => {return res.json()})
  }

  getComponentMenuNav(name:string):ComponentMenuNav{
    let menuName=this._jigsawApiRouter(name);
    return this.menuNavList.find(componentMenu => componentMenu.name === menuName);
  }

  // classes,directives,injectables,interfaces分类下的API合并在一起用jigsaw二级路由表示
  private _jigsawApiRouter(name:string){
    switch(name){
      case "class":
      case "component":
      case "directive":
      case "enum":
      case "injectable":
      case "interface":
      case "module":
      case "typealias": return "jigsaw";
      default: return name
    }
  }


  lastDetailName = new Subject<string>();

  setLastDetailNav(name:string){
    this.lastDetailName.next(name);
  }
  //TODO:后续移步到用户行为服务中处理
  getLastDetailNav():Observable<string>{
    return this.lastDetailName;
  }

  perfectScrollbar: PerfectScrollbarDirective;

  isStartup: Subject<boolean> = new Subject<boolean>();

  setStartup(name:boolean){
    this.isStartup.next(name);
  }
  getStartup():Observable<boolean>{
    return this.isStartup;
  }

  firstVaule: Subject<string> = new Subject<string>();

  setFirstVaule(value:string){
    this.firstVaule.next(value);
  }
  getFirstVaule():Observable<string>{
    return this.firstVaule;
  }

  isApiDemoComponent(name){
    return this.showNormComponentList.indexOf(name) == -1
  }

  apiTypeMap(name){
    switch (name) {
      case "popup":return "injectable";
      case "loading":return "injectable";
      case "time":return "class";
      default :return "component";
    }
  }

  apiNameMap(name){
    switch (name) {
      case "checkbox": return "JigsawCheckBox";
      case "tree": return "JigsawTreeExt";
      default: return "Jigsaw" + name.replace(/( |^|-)([a-z])/g, (found, prefix, char) => char.toUpperCase());
    }
  }
}
