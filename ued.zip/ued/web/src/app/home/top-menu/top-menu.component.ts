import { Component, OnInit } from '@angular/core';
import {UserLoginService} from "../../user/user-login/user-login.service";
import { VersionControlService,Version } from "../../admin/version/version-control.service";
@Component({
  selector: 'ued-top-menu',
  templateUrl: './top-menu.component.html',
  styleUrls: ['./top-menu.component.scss']
})
export class TopMenuComponent implements OnInit {
  version:Version;
  currentUser:any;
  constructor(private userLoginService:UserLoginService) { }

  ngOnInit() {
    this.version=VersionControlService.version;

    this.currentUser = this.userLoginService.currentUserGlobal;
    this.userLoginService.currentUser
      .subscribe(
        data => {
          this.currentUser = data;
        },
        error => console.error(error)
      )
  }

}
