import {Component, OnDestroy, OnInit, Renderer2, ViewContainerRef} from '@angular/core';
import {SearchService} from "../../home/global-search/search.service";
import {UserLoginService} from "../../user/user-login/user-login.service";
import {PLATFORM_ID, Inject} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import * as $ from 'jquery';
import {Subject} from "rxjs/Subject";
import {Router} from "@angular/router";
import {forEach} from "@angular/router/src/utils/collection";
import { VersionControlService,Version} from "../../admin/version/version-control.service";

@Component({
  selector: 'app-ued-search',
  templateUrl: './ued-search.component.html',
  styleUrls: ['./ued-search.component.scss']
})
export class UedSearchComponent implements OnInit, OnDestroy {
  searchIf: boolean = false;
  dropDown: boolean = false;
  sub: number;
  more: number;
  total: number;
  private keyword: string;
  private titleFilter = new Subject<string>();
  pathName: string;
  resultData: any[] = [];
  tag: string = 'all';
  otherModules: any[] = [];
  _document: Function;
  _documentKey: Function;
  warning: boolean = false;
  value: string = "";
  version: Version;



  constructor(public viewContainerRef: ViewContainerRef,
              public renderer: Renderer2,
              private searchService: SearchService,
              private routers: Router,
              @Inject(PLATFORM_ID) private platformId: Object,
              private _userLoginService: UserLoginService
  ) {
  }

  searchShow(event) {
    event.stopPropagation();

    this.searchIf = true;
    this._document = this.renderer.listen(document, 'click', (e) => {//点击全局搜索框外的地方，关闭搜索
      if (!this.searchIf) return;
      if (!$('.closeInput').is(e.target) && $('.closeInput').has(e.target).length === 0) {
        this.searchIf = false;
        this.clearInput(e);
        this._document && this._document();
        this._documentKey && this._documentKey();
      }
    });
    this._documentKey = this.renderer.listen(document, 'keyup', (e) => {//点击全局搜索框外的地方，关闭搜索

      if (!this.searchIf) return;
      if(e.keyCode === 38){
        this.sub--;
        if(this.sub<0){
          this.sub = this.total-1;
        }

      }
      if(e.keyCode === 40){
         this.sub++;
         if(this.sub>this.total-1){
           this.sub = 0;
         }
      }
      if(e.keyCode ===13){
        let target,resultArr:any[];
        if(this.resultData.length>4){
          resultArr = this.resultData.slice(0,4);
          resultArr.push(this.tag);
        }else{
          resultArr = this.resultData;
        }

        this.otherModules.forEach(val=>{
          resultArr.push(val.tagEn);
        });

        if(typeof resultArr[this.sub] === "object"){
          this.routers.navigate([resultArr[this.sub].path,resultArr[this.sub].id]);
        }else{
          this.msgSend({keyword:this.keyword, target:resultArr[this.sub]})
        }
      }
    })
  }

  clearInput(event: Event) {
    event.stopPropagation();
    this.value = "";
  }

  search(keyword: string): void {//搜索你想找的人信息
    this.titleFilter.next(keyword);
  }


  msgSend(x: object): void {
    this.routers.navigate(['/search'], {queryParams: x});
    this.dropDown = true;
    event.stopPropagation();
  }

  ngOnInit() {
    this.version = VersionControlService.version.showProjectModule;
    setTimeout(() => {
      this.searchService.setMsg.emit({keyword: "", target: ""});
    });
    if (isPlatformBrowser(this.platformId)) {
      this.titleFilter
        .debounceTime(300)
        .distinctUntilChanged()
        .subscribe(value => {
          this.sub = -1;
          this.keyword = value;
          this.searchService.getSearchResult(this.keyword)
            .subscribe(rep => {
              if (rep.menus.length === 0 && rep.articles.length === 0 && rep.projects.length == 0 && this.keyword !== "") {
                this.warning = true;
              } else {
                this.warning = false
              }
              this.resultData = [];
              let arr = ["/projects", "/components", "/post"];
              let pathname = window.location.pathname;
              arr = arr.filter(val => {
                return pathname.indexOf(val) != -1
              });
              this.pathName = arr.length > 0 ? arr[0] : "";
              let me = this;
              let collatData = function (rep) {//当搜索出来的目标内容为空或没有指定目标（项目，组件，博文）时的数据处理
                me.otherModules = [];
                if (rep.menus.length > 0) {
                  rep.menus.forEach((val, index) => {
                    let temp = {};
                    temp["tag"] = "组件";
                    temp["path"] = "/components";
                    temp["name"] = val.label;
                    temp["id"] = val.name;
                    me.resultData.push(temp);
                  });
                  me.otherModules.push({
                    "tag": "组件",
                    "tagEn": "components",
                    "tatolNum": rep.menus.length
                  })
                }
                if (me.version && rep.projects.length > 0) {
                  rep.projects.forEach((val, index) => {
                    let temp = {};
                    temp["tag"] = "项目";
                    temp["path"] = "/projects";
                    temp["name"] = val.ProjectName;
                    temp["id"] = val.SerialNum;
                    me.resultData.push(temp);
                  });
                  me.otherModules.push({
                    "tag": "项目",
                    "tagEn": "projects",
                    "tatolNum": rep.projects.length
                  })
                }
                if (rep.articles.length > 0) {
                  rep.articles.forEach((val, index) => {
                    let temp = {};
                    temp["tag"] = "博文";
                    temp["path"] = "/post";
                    temp["name"] = val.title;
                    temp["id"] = val.articleId;
                    me.resultData.push(temp);
                  });
                  me.otherModules.push({
                    "tag": "博文",
                    "tagEn": "post",
                    "tatolNum": rep.articles.length
                  })
                }
              }
              switch (this.pathName) {
                case "/projects":
                  this.tag = "projects";
                  if (rep.projects.length > 0) {
                    rep.projects.forEach((val, index) => {
                      let temp = {};
                      temp["tag"] = "项目";
                      temp["path"] = "/projects";
                      temp["name"] = val.ProjectName;
                      temp["id"] = val.SerialNum;
                      this.resultData.push(temp);
                    });
                    this.otherModules = [];
                    rep.menus.length > 0 && this.otherModules.push({
                      "tag": "组件",
                      "tagEn": "components",
                      "tatolNum": rep.menus.length
                    })
                    rep.articles.length > 0 && this.otherModules.push({
                      "tag": "博文",
                      "tagEn": "post",
                      "tatolNum": rep.articles.length
                    })
                  } else {
                    collatData(rep);
                  }
                  break;
                case "/components":
                  this.tag = "components";
                  if (rep.menus.length > 0) {
                    rep.menus.forEach((val, index) => {
                      let temp = {};
                      temp["tag"] = "组件";
                      temp["path"] = "/components";
                      temp["name"] = val.label;
                      temp["id"] = val.menuId;
                      this.resultData.push(temp);
                    });
                    this.otherModules = [];
                    if(this.version){
                      rep.projects.length > 0 && this.otherModules.push({
                        "tag": "项目",
                        "tagEn": "projects",
                        "tatolNum": rep.projects.length
                      })
                    }
                    rep.articles.length > 0 && this.otherModules.push({
                      "tag": "博文",
                      "tagEn": "post",
                      "tatolNum": rep.articles.length
                    })
                  } else {
                    collatData(rep);
                  }
                  break;
                case "/post":
                  this.tag = "post";
                  if (rep.articles.length > 0) {
                    rep.articles.forEach((val, index) => {
                      let temp = {};
                      temp["tag"] = "博文";
                      temp["path"] = "/post";
                      temp["name"] = val.title;
                      temp["id"] = val.articleId;
                      this.resultData.push(temp);
                    });
                    this.otherModules = [];
                    if(this.version){
                      rep.projects.length > 0 && this.otherModules.push({
                        "tag": "项目",
                        "tagEn": "projects",
                        "tatolNum": rep.projects.length
                      });
                    }
                    rep.menus.length > 0 && this.otherModules.push({
                      "tag": "组件",
                      "tagEn": "components",
                      "tatolNum": rep.menus.length
                    })
                  } else {
                    collatData(rep)
                  }
                  break;
                default:
                  this.otherModules = [];
                  this.tag = "all";
                  collatData(rep);
              }
              this.dropDown = false;
              this.more = this.resultData.length>4?5:this.resultData.length;
              this.total = (this.resultData.length>4?5:this.resultData.length) + this.otherModules.length;
            })
        })
    }
  }

  ngOnDestroy(): void {
    this._document && this._document();
    this._documentKey && this._documentKey();
    this.titleFilter.unsubscribe();
  }
}
