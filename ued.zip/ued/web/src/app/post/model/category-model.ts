export class Category {
  id: number;
  name: string;
  label: string;
}
