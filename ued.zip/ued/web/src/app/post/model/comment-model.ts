/**
 * Created by Administrator on 2017/8/25.
 */

export class PostComment{
  commentId: number;
  serialNum: string;
  content: string;
  time: string;
  uId: string;
  userName:string;
  replyId: number;
  replyName: string;
}
