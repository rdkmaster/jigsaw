import { Component, OnInit,Input,OnChanges } from '@angular/core';
import {Post} from "../model/post-model";
@Component({
  selector: 'app-post-browser-user',
  templateUrl: './post-browser-user.component.html',
  styleUrls: ['./post-browser-user.component.css']
})
export class PostBrowserUserComponent implements OnInit,OnChanges {

  @Input()
  post:Post;

  browserUsers:string[];

  constructor() { }
  ngOnInit() {}

  ngOnChanges():void {
    this.browserUsers = this.post["browserUsersId"] && this.post["browserUsersId"].split(",") || [];
  }

}
