import { Injectable } from '@angular/core';
//import { Http, Response } from '@angular/http'; ng2 http  ---> HttpClient
import { HttpClient,HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { Post,PostAttach } from '../../model/post-model';

@Injectable()
export class PostlistService {
  private postListURL:string = 'rdk/service/app/ued/server/post/post-list';
  private postDetailURL = 'rdk/service/app/ued/server/post/post-detail';
  private postDetailAttachURL = 'rdk/service/app/ued/server/post/post-detail-attach';

  constructor(private http:HttpClient) { }

  public getPostList(cateType: string):Observable<Post[]>{
    //let params = new HttpParams();  ??? HttpParams BUG，无效，使用URL拼接参数
    //if (cateType) {
    //  params.set('category',cateType);
    //}
    return this.http
      .get(`${this.postListURL}?category=${cateType}`)
      .catch((error:any) => Observable.throw(error || 'Server error'));
  }

  public getPostDetial(articleId:string):Observable<Post>{
    //let url = this.postDetailURL;
    //let params = new HttpParams();
    //if (serialNum) {
    //  params.set('serialNum',serialNum);
    //}
    return this.http
      .get(`${this.postDetailURL}?articleId=${articleId}`)
      .map( res => {
        return res[0];
      })
      .catch((error:any) => Observable.throw(error || 'Server error'));
  }

  public getPostAttachList(articleId:string):Observable<PostAttach[]>{
    //let url = this.postDetailAttachURL;
    //let params = new HttpParams();
    //if (serialNum) {
    //  params.set('serialNum',serialNum);
    //}
    return this.http
      .get(`${this.postDetailAttachURL}?articleId=${articleId}`)
      .catch((error:any) => Observable.throw(error || 'Server error'));
  }
}
