import { Injectable }          from '@angular/core';
import {ActivatedRouteSnapshot, CanActivate, Params, Router, RouterStateSnapshot} from '@angular/router';
import 'rxjs/add/operator/switchMap';
import {Observable} from "rxjs/Observable";
import {ProjectService} from "./project-service/project.service";

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private projectService:ProjectService){}
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
      let projectID:string = route.params["id"];

    return true

  }


}
