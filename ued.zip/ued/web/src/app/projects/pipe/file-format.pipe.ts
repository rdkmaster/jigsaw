import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'fileFormat'
})
export class FileFormatPipe implements PipeTransform {
  transform(value: string, args?: any): string {
    if(value === null) return "";
    let format: string = "";
    if(!!args){
      let temp = value.match(args);
      format = !!temp?temp[1]:value;
    }else{
      format = value.slice(value.lastIndexOf('.')+1);
    }

    return format.toLowerCase();
  }

}
