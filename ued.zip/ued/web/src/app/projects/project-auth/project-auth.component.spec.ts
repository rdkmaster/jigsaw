import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectAuthComponent } from './project-auth.component';

describe('ProjectAuthComponent', () => {
  let component: ProjectAuthComponent;
  let fixture: ComponentFixture<ProjectAuthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectAuthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectAuthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
