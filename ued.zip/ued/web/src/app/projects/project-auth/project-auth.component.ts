import {Component, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute, Params, Router} from "@angular/router";
import {ProjectService} from "../project-service/project.service";
import {Project} from "../project";
import {JigsawWarningAlert, PopupInfo} from "@rdkmaster/jigsaw";
import {UserLoginService} from "../../user/user-login/user-login.service";

@Component({
  selector: 'app-project-auth',
  templateUrl: './project-auth.component.html',
  styleUrls: ['./project-auth.component.scss']
})
export class ProjectAuthComponent implements OnInit, OnDestroy {
  project: Project;
  userInfo: any;
  projectName: string;
  teams: any[] = [];
  selectedTeam: string;
  sendMsg: any = null;
  isloading: boolean = false;
  labelTeam: string = "授权此人所属团队";
  labelPerson: string = "授权此人";
  isTooltip: boolean = false;
  userID: any;
  _userLoginInfo: any;
  loginMsg: any;
  timing: number = 0;
  deptRegExp = /([^\/]+)\/.+/;

  constructor(private route: ActivatedRoute,
              private routers: Router,
              private projectService: ProjectService,
              private _userLoginService: UserLoginService) {
  }

  apllySuccess() {

    this.isloading = true;
    let mailTemp = this.projectService.getEmailTemp(this.userInfo, this.project, false);
    let option = {
      "content": {
        "title": "测试：" + this.projectName + "•项目已更新 ",
        "text": mailTemp,
        "imgs": []
      },
      "fromwho": this.userID,
      "towho": {"resId": "", "indv": [this.userInfo.uid]}
    };
    this.projectService.seedMail(option)
      .subscribe(rep => {
        this.isloading = false;
        this.labelTeam = this.labelTeam || "发送成功";
        this.labelPerson = this.labelPerson || "发送成功";
        this.timing = 3;
        let timer = null;
        timer = setInterval(()=>{
          if(this.timing === 1){
            setTimeout(()=>{
              this.routers.navigate(["/"])
            },1000)
            clearInterval(timer);
          }else{
            this.timing--;
          }
        },1000)
      }, error => {
        throw "服务器挂了"
      })
  }

  authPerson() {
    let uid = this.userInfo.uid;
    let pid = this.project.SerialNum;
    this.projectService.addPerAuth(uid, pid)
      .subscribe(rep => {
        this.labelPerson = "";
        this.apllySuccess()
      });
  }

  authTeam() {
    let teamID = this.selectedTeam;
    if (!teamID) {
      this.isTooltip = true;
      return
    }
    let pid = this.project.SerialNum;
    this.projectService.addPerAuth(teamID, pid)
      .subscribe(rep => {
        this.labelTeam = "";
        this.apllySuccess();
      });
  }

  loginIn() {
    if (this.loginMsg) {
      return false;
    } else {
      setTimeout(() => {
        this.loginMsg = JigsawWarningAlert.show('', answer => {
        }, [], '请先登陆', false);
        setTimeout(() => {
          this.loginMsg.dispose();
          this.loginMsg = null;
        }, 2000)
      }, 0);
    }
    return false
  }

  parseQueryString(url) {
    let obj = {};
    let keyvalue = [];
    let key = "", value = "";
    let paraString = url.substring(url.indexOf("?") + 1, url.length).split("&");
    for (let i in paraString) {
      keyvalue = paraString[i].split("=");
      key = keyvalue[0];
      value = keyvalue[1];
      obj[key] = value;
    }
    return obj;
  }

  ngOnInit() {
    let params: any;
    let url = decodeURIComponent(window.location.href);
    params = this.parseQueryString(url);
    let userLogin = this._userLoginService.currentUserGlobal;
    this.userID = !!userLogin ? userLogin.uid : "";
    this._userLoginInfo = this._userLoginService.userInfo$
      .subscribe(rep => {
        this.userID = !!rep ? rep.uid : "";
    });

    if (!params["pid"] || !params["uid"]) {
      throw "链接格式不对"
    }
    let uid = params["uid"];
    let pid = params["pid"];
    this.projectService.getTeamsAuth(uid)
      .subscribe(rep => {
        rep.forEach((val, ind) => {
          let match = val.teamName.match(/-[A-Z]\s*(.+)/);
          if (!!match) {
            val.teamName = match[1]
          }
          this.teams.push(val);
        });
      });
    this.projectService.getProjectDetail(pid)
      .subscribe(rep => {
        this.project = rep;
        this.projectName = !!rep.ProjectName.match(/\](\S*)/) ? rep.ProjectName.match(/\](\S*)/)[1] : rep.ProjectName
      });
    this.projectService.getUserInfo(uid)
      .subscribe(rep => {
        this.userInfo = rep.data;
      })
  }

  ngOnDestroy(): void {
    this._userLoginInfo.unsubscribe();
  }
}
