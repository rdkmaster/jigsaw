import {
  Component, ElementRef, OnDestroy, OnInit, ViewChild, AfterViewInit, Renderer2,
  EventEmitter
} from '@angular/core';
import {ProjectService} from "../project-service/project.service";
import {ActivatedRoute, Params, Router} from '@angular/router';
import {DomSanitizer} from "@angular/platform-browser";
import {Project} from "../project";
import * as $ from 'jquery';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/map';
import {
   CheckBoxStatus, JigsawInput

} from "@rdkmaster/jigsaw";
import set = Reflect.set;
import {UserLoginService} from "../../user/user-login/user-login.service";
import {SearchService} from "../../home/global-search/search.service";
import {listAnimation, showAnimation, toggleAnimation, zoomIn} from "app/animations/animate";
import {Observable} from "rxjs/Observable";
import {Subject} from "rxjs/Subject";

@Component({
  selector: 'app-project-detail',
  templateUrl: './project-detail.component.html',
  styleUrls: ['./project-detail.component.scss'],
  animations: [listAnimation, showAnimation, zoomIn, toggleAnimation]
})
export class ProjectDetailComponent implements OnInit, OnDestroy, AfterViewInit {
  currentUser: any;
  projectDetail: Project = new Project();
  projectDetailImgs: string[] = [];
  projectDocsShow: boolean;
  searchbl: boolean = false;
  errorBox: boolean = true;
  isContent: boolean = false;
  projectID: string;

  prototypeZip: any;
  imagesZip: any;

  highlight: boolean;
  isSubscribe: boolean;
  numImgs: number;
  targetImg: number = 0;
  isBigImg: boolean = false;

  tableDatas: any[];
  authorises: any[] = [];
  showSave: boolean = false;

  searchAuthorise: any;
  stateAuthorise: boolean;
  showPermiss: any[];
  showBtn: boolean = false;
  authorArr: string[];
  hiddenText: boolean = true;
  projectsArr: any[] = [];
  isProjectsArr: boolean = false;
  keyword: string;
  allSearchs: Observable<any>;
  dropDownShow: boolean = true;
  searchTerms = new Subject<string>();

  timer: any = null;
  timer1: any = null;
  tooltipPos: boolean = true;

  stateShow: string = 'hide';
  iconDes: string = "fa-search";
  reg: any = /\/([^/]+)\.[a-zA-Z]+/i;
  promptWords: string = "搜索用户，请输入姓名/工号";
  moveWidth: number = 200;
  isUseRole: boolean = false;
  _userLoginInfo: any;
  isFollowed: boolean = false;
  collecTooContent: string;
  checkedState = CheckBoxStatus.checked;
  personInfo: any;
  smInfors: any[];
  disabled: boolean = false;
  isTooltip: boolean = false;
  selectedMan: string;
  label: string = "立即申请";
  deptRegExp = /([^\/]+)\/.+/;

  prototypePack: object;
  annotationPack: object;

  guidanceInfor: any;
  @ViewChild('searchInput') searchInput: JigsawInput;


  constructor(private projectService: ProjectService,
              private route: ActivatedRoute,
              private sanitizer: DomSanitizer,
              private routers: Router,
              private ele: ElementRef,
              private _renderer: Renderer2,
              private searchService: SearchService,
              private _userLoginService: UserLoginService) {

  }

  animationDone(event) {
    event.toState == 5 && (this.stateShow = "show");
  }

  getTargetImg(target) {
    this.targetImg = target;
    return false;
  }
  marking() { //是否关注此项目
    clearTimeout(this.timer1);
    this.route.params
      .switchMap((params: Params) => {
        return this.projectService.updateProjectFollowed({
          'SerialNum': params['id'],
          'state': !this.highlight
        })
      })
      .subscribe(res => {
          this.highlight = !this.highlight;
          this.collecTooContent = this.highlight ? "收藏成功, <a href='/projects#collect' target='_blank'>查看我的收藏</a>" : "收藏已取消";
          this.tooltipPos = true;
          this.isFollowed = true;
          this.timer1 = setTimeout(val => {
            this.isFollowed = false;
          }, 2000);
        },
        error => {
          this.collecTooContent = "服务器挂了，操作失败"
        });

  }

  subscribe() { //是否订阅此项目
    clearTimeout(this.timer1);
    this.route.params
      .switchMap((params: Params) => {
        return this.projectService.updateProjectSubscribe({
          'SerialNum': params['id'],
          'state': !this.isSubscribe
        })
      })
      .subscribe(res => {
        this.isSubscribe = !this.isSubscribe;
        this.collecTooContent = this.isSubscribe ? "订阅成功，项目有更新就会邮件通知您。" : "订阅已经取消，你不会再收到该项目的更新通知。";
        this.tooltipPos = false;
        this.isFollowed = true;
        this.timer1 = setTimeout(val => {
          this.isFollowed = false;
        }, 2000);
      },error => {
      this.collecTooContent = "服务器挂了，操作失败"
    });
  }

  mailCall(arr) {//给开通权限的人发送邮件通知
    let projectName = this.projectDetail.ProjectName;
    console.log(arr);
    this.projectService.getUserInfo()
      .subscribe(rep => {
          let userInfo = rep.data;
          this.projectService.getTeamMembers(arr)
            .subscribe(res => {
              if(!res.members.length) return;
              this.authorArr = res.members;
              let AuthorizeHtml = this.projectService.getAuthorizeHtml(userInfo,projectName)
              let option = {
                "content": {
                  "title": "测试：" + projectName + "•项目已更新 ",
                  "text": AuthorizeHtml,
                  "imgs": []
                },
                "fromwho": userInfo.uid,
                "towho": {"resId": "", "indv": this.authorArr}
              };
              this.projectService.seedMail(option)
                .subscribe(rep => {
                  if (rep == "done") {
                    // this.sendPrompting = "发送成功";
                    // this.emailClass = "fa fa-check-circle";
                  } else {
                    // this.sendPrompting = "发送失败";
                    // this.emailClass = "fa fa-times-circle";
                    throw "Sorry! 发送失败";
                  }
                  // setTimeout(() => {
                  //   this.sendPrompting = "邮件通知";
                  //   this.emailClass = "fa fa-envelope"
                  // }, 1000)
                });
            });
        },
        error => {
          throw ("Sorry!服务器出问题了，请稍后再试");
        });
  }

  search(keyword: string): void {//搜索你想找的人信息
    $(".authoriseContent").slideUp();
    this.dropDownShow = false;
    this.searchTerms.next(keyword);
  }

  btnLeft() {
    let left = this.ele.nativeElement.getElementsByClassName("imgWidth")[0];
    let btnLeft = this.ele.nativeElement.getElementsByClassName("btn-left")[0];
    let btnRight = this.ele.nativeElement.getElementsByClassName("btn-right")[0];
    let trans = left.style.transform;
    let length = this.projectDetailImgs.length;
    let num;
    btnRight.style.display = "block";
    if (length > 5) {
      num = Number(trans.slice(11, -3));
      if (-parseInt(num) <= (length - 6) * this.moveWidth) {
        left.style.transform = "translateX(" + (num - this.moveWidth) + "px)";
        if ((-num / this.moveWidth + 6.5) >= length) {
          btnLeft.style.display = "none";
        }
      }
    }
    return false;
  }

  handlerBigImg(){
    this.isBigImg = true;
    return false;
  }
  btnRight() {
    let right = this.ele.nativeElement.getElementsByClassName("imgWidth")[0];
    let btnLeft = this.ele.nativeElement.getElementsByClassName("btn-left")[0];
    let btnRight = this.ele.nativeElement.getElementsByClassName("btn-right")[0];
    let trans = right.style.transform;
    let num;
    btnLeft.style.display = "block";
    if (trans) {
      num = Number(trans.slice(11, -3));
      if (!parseInt(num)) {
        return false;
      }
      right.style.transform = "translateX(" + (num + this.moveWidth) + "px)";
      if (num + this.moveWidth >= 0) {
        btnRight.style.display = "none";
      }
    }
    return false;
  }

  canSearch(icon, prompt, e) {

    if (this.searchbl && this.iconDes == icon) {
      e.target.style.color = '#fff';
      this.searchbl = !this.searchbl;
    } else if (this.searchbl && this.iconDes !== icon) {
      $(e.target).siblings().css('color', '#fff');
      e.target.style.color = 'rgba(255,255,255,.255)';
      this.iconDes = icon;
      this.promptWords = prompt;
    } else {
      e.target.style.color = 'rgba(255,255,255,.5)';
      this.searchbl = !this.searchbl;
      this.iconDes = icon;
    }
  }

  Onclick(key) {//根据工号搜人有没有权限
    this.dropDownShow = true;
    this.projectService.getAuthorized(JSON.stringify(this.projectID), key)
      .subscribe(value => {
        if (!!value) {
          this.errorBox = true;
          this.searchAuthorise = value.data;
          this.stateAuthorise = value.state;
          this.projectService.testUserID(value.data.uid)
            .subscribe(name => {
            });
        } else {
          this.errorBox = false;
        }
      })
    setTimeout(() => {
      $(".authoriseContent").slideDown();
    }, 200)
  }

  addAuthorise() {// 给搜的人加权限
    this.authorises.push({
      id: this.searchAuthorise.uid,
      name: this.searchAuthorise.name,
      total: false
    });
    $(".authoriseContent").slideUp();
    this.searchInput.value = "";
  }

  tagClose(seleted, index) {//去除某个团队或个人权限
    let tagData = this.authorises.splice(index, 1)[0];
    Number(seleted) && this.tableDatas.push(tagData);
  }

  addSelectedTeam(data, index) {//添加某个团队
    this.authorises.push({name: data.name, id: data.id, total: data.total, projectType: data.projectType});
    this.tableDatas.splice(index, 1);
  }

  allSelected() {//全选
    if (this.tableDatas.length) {
      let tableDatas = JSON.parse(JSON.stringify(this.tableDatas));
      this.tableDatas = [];
      this.authorises = this.authorises.concat(tableDatas);
    }
  }

  banner(num) {//选择图片
    this.targetImg = num;
  }

  viewBtn() {//查看全部有权限的内容
    this.showPermiss = JSON.parse(JSON.stringify(this.authorises));
    this.showBtn = false;
  }
  permission(state?: string) {// 确定要加权限的人或团队
    $(".detailPermission").slideToggle();
    // this.tableData = new TableData(this.tableData.data, this.tableData.field, this.tableData.header)
    let stringId = "";
    if (state == "ok") {
      this.authorises.forEach(function (item) {
        if (stringId == "") {
          stringId = item.id
        } else {
          stringId += ',' + item.id;
        }
      });
      this.route.params//更新显示权限列表
        .switchMap((params: Params) => {
          return this.projectService.updateProjectTeamLists(params["id"], stringId)
        })
        .subscribe(name => {
          console.log(this.showPermiss,this.authorises);
          let permissArr=[],authorArr=[],sendArr=[];
          this.showPermiss.forEach(val=>{
               permissArr.push(val.id);
          });
          this.authorises.forEach(val=>{
            authorArr.push(val.id);
          });
          sendArr = authorArr.filter(val=>{
              if(permissArr.indexOf(val)===-1) return true;
          });
          this.checkedState && this.mailCall(sendArr);

          this.showPermiss = JSON.parse(JSON.stringify(this.authorises));
          this.showBtn = this.showPermiss.length > 6 ? true : false;
          this.showPermiss = this.showBtn ? this.showPermiss.slice(0, 5) : this.showPermiss;
          this.showSave = !this.showSave;
        });
    } else {
      setTimeout(()=>{
        $('.g-main').scrollTop(320);
      },500);
      this.showSave = !this.showSave;
    }
  }

  relatedSend(x: object): void {
    this.routers.navigate(['/search'], {queryParams: x});
    event.stopPropagation();
  }

  nameFormat(value) {
    let reg = /^VMAX\-[a-zA-Z]/i;
    if (reg.test(value.name)) {
      value.projectType = value.name.match(/(^VMAX\-[a-zA-Z])\s*\S+/i)[1];
      value.name = value.name.match(/^VMAX\-[a-zA-Z]\s*(\S+)/i)[1];
    } else {
      value.projectType = "其它"
    }
    return value
  }

  seedApplication() {
    if (!this.selectedMan) {
      this.isTooltip = true;
      return
    }
    this.disabled = true;
    this.label = "";
    let template = this.projectService.getEmailTemp(this.personInfo, this.projectDetail, true);
    let option = {
      "content": {
        "title": "测试：" + this.projectDetail.ProjectName + "•项目已更新 ",
        "text": template,
        "imgs": []
      },
      "fromwho": 6176000041,
      "towho": {"resId": "", "indv": [this.selectedMan]}
    };
    this.projectService.seedMail(option)
      .subscribe(rep => {
        this.disabled = false;
        this.label = "申请成功";
      }, error => {
        this.disabled = false;
        this.label = "申请失败";
        throw "发送失败 ";
      });
  }

  guidanceHandle(event: Event,name: string){
    event.stopPropagation();
    if(name==='collection'){
      let collection = this.guidanceInfor.collection;
      if(collection===1){
        this.guidanceInfor.collection = 2;
      }else{
        this.guidanceInfor.collection=0;
        this.projectService.setGuidanceCollection(3);
        this.routers.navigate(['/projects'],{fragment:"collect"});
      }
    }else if(name==='subscribe'){
        this.projectService.updateGuidance({subscribe:1})
          .subscribe(res=>{this.guidanceInfor.subscribe=0})
    }else if(name==='download'){
      this.projectService.updateGuidance({download:1})
        .subscribe(res=>{this.guidanceInfor.download=0})
    }else{
      this.projectService.updateGuidance({label:1})
        .subscribe(res=>{this.guidanceInfor.label=0})
    }
    return false;
  }
  ngOnInit(): void {
    this.currentUser = !!this._userLoginService.currentUserGlobal ? this._userLoginService.currentUserGlobal : "";
    this.isUseRole = !!this.currentUser && this.currentUser.roles == "199";
    this._userLoginInfo = this._userLoginService.userInfo$
      .subscribe(rep => {
          this.isUseRole = !!rep && rep.roles == "199";
        },
        error => console.error(error));

    this.allSearchs = this.searchTerms//关键字搜索获取数据
      .debounceTime(300) //300毫秒中内容没有变才进行
      .distinctUntilChanged()//内容改变才进行
      .switchMap(keyword => {
        return this.projectService.searchtAddress(keyword);
      });
    this.route.params
      .switchMap((params: Params) => {
        this.projectID = params["id"];
        return this.projectService.getProjectDetail(params["id"]);
      })
      .subscribe(projects => {
        this.projectService.getAuthorized(this.projectID, this.currentUser.uid)
          .subscribe(res=>{
            if(!res.state){
              this.projectDetail = projects;
              this.isContent = false;
              this.projectService.getUserInfo()
                .subscribe(rep => {
                  this.personInfo = rep.data;
                  this.projectService.getSmAuth(this.projectDetail.SerialNum)
                    .subscribe(rep => {
                      this.smInfors = rep;
                    });
                });
            }else{
              this.isContent = true
              let url = projects.PrototypeView;
              let index = url.lastIndexOf("/");
              let name = projects.ProjectName.replace(/\[.+\]/, "");
              document.title = document.title + " " + name;
              let reg = /ux\/ued-resource/;
              projects.CreatTime = projects.CreatTime.slice(0, 10);
              projects.UpdateTime = projects.UpdateTime.slice(0, 10);
              projects.PrototypeView = projects.PrototypeView && this.sanitizer.bypassSecurityTrustUrl(projects.PrototypeView);
              projects.RequirementDoc = JSON.parse(projects.RequirementDoc);
              let requirementDoc = [];
              projects.RequirementDoc.forEach((value, index) => {
                let jsonObj = JSON.parse(value)
                if(jsonObj.name ==='标注图'){
                  this.annotationPack = jsonObj
                }else{
                  requirementDoc.push(jsonObj);
                }
              });
              projects.RequirementDoc = requirementDoc;
              projects.RequirementDoc = projects.RequirementDoc.filter(value => {//e办上的链接禁掉
                let reg = /\/ux\/\S+\/\S+\.zip$/
                return !reg.test(value.url);
              });
              if (reg.test(url)) {// 原型自动打包zip
                this.prototypeZip = url.slice(0, index) + "/原型-" + name + ".zip";
                this.prototypePack={name: "原型文件",url:this.prototypeZip};
                projects.RequirementDoc.unshift();
                this.projectService.getPrototypeZip(projects.ProjectName)
                  .subscribe(req=>{

                  },err=>{
                    console.log(err)
                  });
              } else {

                this.prototypeZip = projects.PrototypeZip ? this.sanitizer.bypassSecurityTrustUrl(projects.PrototypeZip) : ""
              }
              this.hiddenText = projects.ProjectBrief.length > 300 ? false : true;

              this.projectDocsShow = !projects.RequirementDoc.length;
              let projectName = projects.ProjectName;

              this.keyword = projectName.match(/\[(\S*)\]/) ? projectName.match(/\[(\S*)\]/)[1] : "";
              this.projectDetail = projects;
              this.projectService.getProjectsRelated(this.keyword)
                .subscribe(res => {
                  this.projectsArr = res.data.filter((val, index) => {
                    return val.ProjectName !== projectName
                  }).splice(0, 5);
                  this.isProjectsArr = !!this.projectsArr.length ? false : true;
                });
              this.route.params
                .switchMap((params: Params) => {
                  return this.projectService.getProjectDetailImgs(params["id"]);
                })
                .subscribe(projectImgs => {//图片自己打包zip

                  this.numImgs = projectImgs.length;
                  this.projectDetailImgs = projectImgs.filter(val => {
                    let reg = /.+(\.jpg|\.png|\.gif|\.jpeg|\.bmp)/i;
                    return reg.test(val);
                  });
                  if (this.numImgs !== 0) {
                    if (reg.test(projectImgs[0])) {
                      let url = projectImgs[0];
                      let index = url.lastIndexOf("/");
                      this.imagesZip = url.slice(0, index) + "/效果图-" + name + ".zip";
                      this.projectService.getImagesZip(projects.ProjectName)
                        .subscribe(rep => {
                          let hash = window.location.hash;
                          if (hash) {
                            $('.g-main').scrollTop($(hash).offset().top - 60)
                          }
                        })
                    }
                  }
                });
            }
         })
      });

    this.route.params
      .switchMap((params: Params) => {//得到授权的团队和个人数据
        return this.projectService.getProjectAuthorises(JSON.stringify(params["id"]))
      }).subscribe(target => {
      target.map(value => {
        return this.nameFormat(value);
      });
      this.showPermiss = target;
      this.showBtn = this.showPermiss.length > 6 ? true : false;
      this.showPermiss = this.showPermiss.length > 6 ? this.showPermiss.slice(0, 5) : this.showPermiss;
      this.authorises = JSON.parse(JSON.stringify(target));
    });
    this.route.params//得到没有授权的团队数据
      .switchMap((params: Params) => {
        return this.projectService.getProjectTeamLists(JSON.stringify(params["id"]));
      })
      .subscribe(teams => {

        this.tableDatas = teams.table.filter(value => {
          return value.id != "T1001"
        });
        this.tableDatas.map(value => {
          return this.nameFormat(value);
        })
      });
    this.route.params
      .switchMap((params: Params) => {
        return this.projectService.getProjectFollowed(JSON.stringify(params["id"]))

      })
      .subscribe(res => {
        this.highlight = res == 1 ? true : false;
      });

    this.route.params
      .switchMap((params: Params) => {
        return this.projectService.getProjectSubscribe(JSON.stringify(params["id"]))
      })
      .subscribe(res => {
        this.isSubscribe = res == 1 ? true : false;
      });
    $(document).mouseup((e) => {
      if (!$(".dropBlock").is(e.target) && $(".dropBlock").has(e.target).length === 0) {
        $(".authoriseContent").slideUp();
      }
    })
    // // 提示功能;
    this.projectService.getGuidanceInfor()
      .subscribe(response=>{
        this.guidanceInfor = response;
      })
  }

  ngAfterViewInit(): void {

  }

  ngOnDestroy(): void {
    clearTimeout(this.timer);
    this.searchTerms.unsubscribe();
    this._userLoginInfo.unsubscribe();
    document.title = "ZTE-UED";
  }
}
