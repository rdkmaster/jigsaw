import {
  Component, OnInit, ViewContainerRef, Renderer2, ViewChild, OnDestroy, ElementRef,
  ContentChild
} from '@angular/core';
import {Project} from "../project";
import {ProjectService} from "../project-service/project.service";
import {Observable} from 'rxjs/Observable';
import {DomSanitizer} from "@angular/platform-browser";
import {JigsawWarningAlert, PopupInfo, PopupService} from "@rdkmaster/jigsaw";
import {UserLoginService} from "../../user/user-login/user-login.service";
import {Subject} from "rxjs/Subject";
import {listAnimation, showAnimation} from "../../animations/animate";
import {Router} from "@angular/router";

declare let $: any;

@Component({
  selector: 'app-project-list',
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.scss'],
  animations: [listAnimation,showAnimation]
})
export class ProjectListComponent implements OnInit, OnDestroy {
  projectLists: Project[] = [];
  boo: boolean = true;
  collectTag: boolean = false;
  projectTarget: Project;
  smInfors: any[];
  selectedMan: string;
  _templateRef: PopupInfo;
  personInfo: any;
  viewportShow: boolean;
  projectBase: boolean = true;
  viewPortHide: boolean = true;
  _documentListe: Function;
  _userLoginInfo: any;
  collonClone: Project[] = [];
  disabled: boolean = false;
  private triggerInterval = new Subject<string>();
  @ViewChild('unauthor') unauthor: any;
  @ViewChild('authorized') authorized: any;
  nums: number = 12;
  max: number;
  userID: any;
  tagWord: string;
  colList: Project[] = [];
  loginMsg: any;
  label: string = "立即申请";
  isShow: boolean = true;
  isTooltip: boolean = false;
  deptRegExp = /([^\/]+)\/.+/;

  n: number = -1;
  collection: number;

  constructor(private projectService: ProjectService,
              private sanitizer: DomSanitizer,
              private _renderer: Renderer2,
              private routers: Router,
              private _popupService: PopupService,
              private _userLoginService: UserLoginService
              ) {};

  loginIn() {
    if (this.loginMsg) {
      return false;
    } else {
      setTimeout(() => {
        this.loginMsg = JigsawWarningAlert.show('', answer => {
        }, [], '请先登陆', false);
        setTimeout(() => {
          this.loginMsg.dispose();
          this.loginMsg = null;
        }, 2000)
      }, 0);
    }
    return false
  }

  authority(project: Project, hash: string) {
    this.label = "立即申请";
    if (!this.userID) {
      this.loginIn();
      return false
    }
    this.disabled = false;
    this.projectTarget = project;

    this.projectService.getAuthorized(project.SerialNum, this.userID, true)
      .then(rep => {
        if (rep.state) {
          if (this._templateRef) {
            this._templateRef.dispose();
          }
          // this.routers.navigate(["/projects/"+project.SerialNum]);
          let url = window.location.origin + window.location.pathname + "/" + project.SerialNum + (!!hash ? hash : "");
          let a = document.createElement("a"); //创建a对象
          a.setAttribute("href", url);
          a.setAttribute("target", "_blank");
          a.setAttribute("id", "camnpr");
          document.body.appendChild(a);
          a.click(); //执行当前对象
        } else {
          this.projectService.getUserInfo()
            .subscribe(rep => {
              this.personInfo = rep.data;
              this.projectService.getSmAuth(this.projectTarget.SerialNum)
                .subscribe(rep => {
                  this.smInfors = rep;
                  if (this.isShow) {
                    this.isShow = false;
                    if (this._templateRef) {
                      this._templateRef.dispose();
                    }
                    this._templateRef = this._popupService.popup(this.unauthor);
                    this.isTooltip = false;
                  }
                });
            });
        }
      });
    return false;
  }

  seedApplication() {
    if (!this.selectedMan) {
      this.isTooltip = true;
      return
    }
    this.disabled = true;
    this.label = "";
    let template = this.projectService.getEmailTemp(this.personInfo, this.projectTarget, true);
    let option = {
      "content": {
        "title": "测试：" + this.projectTarget.ProjectName + "•项目已更新 ",
        "text": template,
        "imgs": []
      },
      "fromwho": this.userID,
      "towho": {"resId": "", "indv": [this.selectedMan]}
    };
    this.projectService.seedMail(option)
      .subscribe(rep => {
        this.closeTemplate();
        this.disabled = false;
        this.label = "申请成功";
      }, error => {
        this.disabled = false;
        this.label = "申请失败";
        throw "发送失败 ";
      });
  }

  tagClose() {
    this.tagWord = "";
    this.projectLists = JSON.parse(JSON.stringify(this.collonClone));
  }

  tagWordFilter(keyword?: string) {
    if (!this.userID) {
      this.loginIn();
      return;
    }
    this.tagWord = keyword;
    this.projectService.getProjectListFilter(this.tagWord)
      .subscribe(projects => {
        this.projectLists = this.formatParamer(projects.data);
      }, error => {

      })
  }

  collectList() {
    if (this.colList.length === 0) {
      this.projectService.getProjectCollect()
        .subscribe(projects => {
          projects = this.formatParamer(projects);
          this.projectLists = projects;
          this.projectBase = true;
          this.viewPortHide = true;
        })
    }
    else {
      this.projectLists = this.colList;
    }
  }

  closeTemplate() {
    this._templateRef.dispose();
    this.selectedMan = "";
    this.isShow = true;
  }

  formatParamer(projects) {
    for (let i = 0; i < projects.length; i++) {
      let resMatch = projects[i].ProjectName.match(/\[(\S*)\]/);
      if (!!resMatch) {
        projects[i].tagArr = resMatch[1].split('&').slice(0, 3);
        projects[i].ProjectName = projects[i].ProjectName.match(/\](\S*)/)[1];
      } else {
        projects[i].tagArr = []
      }
      projects[i].PrototypeView = this.sanitizer.bypassSecurityTrustUrl(projects[i].PrototypeView);
    }
    return projects
  }

  onScroll = function () {
    this.boo && this.triggerInterval.next();
  };

  isElementInViewport(el, offset) {
    offset = offset || -20;
    let top = el.offsetTop;
    let winTop = $('.g-main').height();
    let winScrollTop = $('.g-main').scrollTop();
    return !(top > winScrollTop && winScrollTop < (top-winTop + offset));
  }

  listprojects(nums) {

    this.viewPortHide = false;
    this.projectService.getProjectList(nums)
      .subscribe(projects => {
        projects = this.formatParamer(projects);
        this.collonClone = [...this.collonClone,...projects];
        this.projectLists = [...this.projectLists,...projects];
        this.viewPortHide = true;
        if (this.nums === this.max) {
          this.projectBase = false;
        }
      }, err => {
        // window.location.reload();
      })
  }

  hashListen() {
    if (!this.userID) {
      this.loginIn();
      return;
    }
    if (window.location.hash === '#collect') {
      this.tagWord ="";
      this.collectTag = false;
      if (this.boo) {
        this.boo = false;
        this.collectList();
      }
    } else {
        this.collectTag = true;
        this.boo = true;
        this.projectLists = this.collonClone
    }
  }

  mouseEnter(id,index){//控制项目介绍是否显示
    if(index === this.n || !this.userID ) return;
    this.projectService.getAuthorized(id, this.userID)
      .subscribe(req=>{
          this.n = req.state?index: -1;
      },error=>{
         console.log(error);
      })
  }
  clickCollectPrompt(event){
    event.stopPropagation();
    this.collection = 0;
    this.projectService.updateGuidance({collection:1})
      .subscribe(res=>{

      });
    return false;
  }
  ngOnInit() {
    this.collection=this.projectService.getGuidanceCollection;
    this.projectService.getProjectListMax()
      .subscribe(max => {
        this.max = max;
      });

    let viewport = document.getElementsByClassName("viewport")[0];
    this.triggerInterval
      .debounceTime(300)
      .subscribe(res => {

        this.viewportShow = this.isElementInViewport(viewport, -100);
        if (!this.viewportShow || !!this.tagWord || window.location.hash === '#collect') {
          return;
        }
        if (this.nums < this.max) {
          if (this.nums + 12 < this.max) {
            this.nums = this.nums + 12;
          } else {
            this.nums = this.max;
          }
          this.listprojects(this.nums)
        }
      });
    let userLogin = this._userLoginService.currentUserGlobal;
    this.userID = !!userLogin ? userLogin.uid : "";
    this._userLoginInfo = this._userLoginService.userInfo$
      .subscribe(rep => {
        this.userID = !!rep ? rep.uid : "";
      });
    let me = this;
    let ele = document.getElementsByClassName("g-main")[0];
    this._documentListe = this._renderer.listen(ele, 'scroll', me.onScroll.bind(me));
    this.listprojects(this.nums);
    this.hashListen();
    window.addEventListener("hashchange", this.hashListen.bind(this), false)

  }

  ngOnDestroy(): void {
    this._documentListe && this._documentListe();
    this._userLoginInfo.unsubscribe();
    this.triggerInterval.unsubscribe();
    window.removeEventListener("hashchange", this.hashListen, false)
  }
}
