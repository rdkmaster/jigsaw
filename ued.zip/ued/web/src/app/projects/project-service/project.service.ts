/**
 * Created by 6176000041 on 2017/7/28.
 */
import {EventEmitter, Injectable} from '@angular/core';
import {Headers, Http, RequestOptions, Response} from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Project } from "../project";
import { Observable } from 'rxjs/Observable'
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/filter';
import "rxjs/add/operator/toPromise";

@Injectable()
export class ProjectService {

  private headers = new Headers({'Content-Type': 'application/json'});
  private projectListUrl = 'rdk/service/app/ued/server/project/latestCreatedProjectList';
  private projectDetailUrl = 'rdk/service/app/ued/server/project/projectDetail';
  private projectCollectUrl = 'rdk/service/app/ued/server/project/projectCollect';
  private projectListMaxUrl = 'rdk/service/app/ued/server/project/latestCreatedProjectMaxNum';
  private projectListTargetUrl = 'rdk/service/app/ued/server/project/latestCreatedProjectTargets';
  private projectListImgUrl = 'rdk/service/app/ued/server/project/latestCreatedProjectDetailImgs';
  private projectPermissionUrl = 'rdk/service/app/ued/server/project/projectPermission';
  private projectDeletePermissionUrl = 'rdk/service/app/ued/server/project/projectDeletePermission';
  private projectAddPermissionUrl = 'rdk/service/app/ued/server/project/projectAddPermission';
  private addPersonUrl = 'rdk/service/app/ued/server/project/addPerson';
  private projectEditPermissionUrl = 'rdk/service/app/ued/server/project/projectEditPermission';

  private projectAuthorizedUrl = 'rdk/service/app/ued/server/sys/authority/groupListByPID';
  private testUserIDUrl = 'rdk/service/app/ued/server/project/testUserID';
  private projectTeamListdUrl = 'rdk/service/app/ued/server/sys/authority/teamList';
  private addPerAuthUrl = 'rdk/service/app/ued/server/sys/authority/addPersonAuthorized';
  private getTeamsAuthUrl = 'rdk/service/app/ued/server/sys/authority/getTeamsAuth';
  private projectUpdatePrivilegeUrl = 'rdk/service/app/ued/server/sys/authority/updatePrivilege';
  private projectIsAuthorizedUrl = 'rdk/service/app/ued/server/sys/authority/isAuthorized';
  private getSmAuthUrl = 'rdk/service/app/ued/server/sys/authority/getSmAuth';

  private userInfoUrl = 'rdk/service/app/ued/server/project/userInfo';
  private projectFollowedUrl = 'rdk/service/app/ued/server/project/projectFollowed';
  private projectGetFollowedUrl = 'rdk/service/app/ued/server/project/projectGetFollowed';
  private getSubscriptionUrl = 'rdk/service/app/ued/server/project/getSubscription';
  private projectSubscriptionUrl = 'rdk/service/app/ued/server/project/projectSubscription';
  private authorOfficerUrl = 'rdk/service/app/ued/server/project/authorOfficer';
  private prototypeZip = 'rdk/service/app/ued/server/project/prototypeZip';
  private imagesZip = 'rdk/service/app/ued/server/project/imagesZip';
  private projectsRelated = 'rdk/service/app/ued/server/project/projectsRelated';
  private projectListFilter = 'rdk/service/app/ued/server/project/projectListFilter';
  private getTeamMembersUrl = 'rdk/service/app/ued/server/project/getTeamMembers';

  private guidanceInfor = 'rdk/service/app/ued/server/guidance/guidanceInfor';
  private updateGuidanceUrl = 'rdk/service/app/ued/server/guidance/updateGuidance';


  change: EventEmitter<any>;//自定义事件
  private guidanceCollection: number;
  constructor(
    private http: Http,
    private http2:HttpClient
  ) {
      this.change = new EventEmitter();
  }
  setGuidanceCollection(n:any){
    this.guidanceCollection = n;
  }
  get getGuidanceCollection(){
    return this.guidanceCollection
  }
  getformat(str: string){
    if(str){
      let deptRegExp = /([^\/]+)\/.+/;
      let temp = str.match(deptRegExp);
      return !!temp?temp[1]:str;
    }
    return str;
  }


  //获得项目列表数据
  getProjectList(nums?:number): Observable<Project[]> {
    return this.http.get(`${this.projectListUrl}?nums=${nums}`)
      .map(response => JSON.parse(response["_body"]).data)
  }

  //获得最项目总数
  getProjectListMax(): Observable<number> {
    return this.http.get(`${this.projectListMaxUrl}`)
      .map(response => JSON.parse(response["_body"]).maxnum)
  }

  //根据项目标签获得其类
  getProjectListTarget(target: string): Observable<Project[]> {
    return this.http.get(`${this.projectListTargetUrl}?target=${target}`)
      .map(response => JSON.parse(response["_body"]).data)
  }

  //根据项目ID获得其详情
  getProjectDetail(pid:string): Observable<Project> {
    pid = JSON.stringify(pid);
    return this.http2.get(`${this.projectDetailUrl}?SerialNum=${pid}`)
      .map(response=> {return response["data"][0]})
  }

  //根据工号获得其收藏的项目列表
  getProjectCollect(): Observable<Project[]> {
    return this.http.get(`${this.projectCollectUrl}`)
      .map(response=> {return JSON.parse(response["_body"]).data})
  }

  //根据项目ID 获得其图片列表
  getProjectDetailImgs(id:string):Observable<string[]> {
    id = JSON.stringify(id);
    return this.http.get(`${this.projectListImgUrl}?id=${id}`)
      .map(response => JSON.parse(response["_body"]).data)
  }

  //获得队名和其队内的成员
  getProjectPermission(): Observable<any> {
    return this.http.get(`${this.projectPermissionUrl}`)
      .map(response => {
          return JSON.parse(response["_body"]).data})
  }

  //删除一个队内的一个人
  deleteProjectPermission(team:string,uid:string): Observable<any> {
    return this.http.get(`${this.projectDeletePermissionUrl}?uid=${uid}&team=${team}`)
      .map(response => {
        return response})
  }

  //创建一个团队
  addProjectPermission(teams:any): Observable<any> {
    return this.http.post(this.projectAddPermissionUrl, {data: teams}, {headers: this.headers})
  }

  //编辑一个团队
  editProjectPermission(teams:any,teamName: string): Observable<any> {
    return this.http.post(this.projectEditPermissionUrl, {data: teams,teamName:teamName}, {headers: this.headers})
  }

  //详情页内的关注功能  （取消或添加)
  updateProjectFollowed(followed:any): Observable<any> {
    return this.http.post(this.projectFollowedUrl, {data: followed}, {headers: this.headers})
  }

  //详情页内的订阅功能  （取消或订阅)
  updateProjectSubscribe(followed:any): Observable<any> {
    return this.http.post(this.projectSubscriptionUrl, {data: followed}, {headers: this.headers})
  }

  //获得是否被关注的值
  getProjectFollowed(SerialNum: string): Observable<any> {
    return this.http.get(`${this.projectGetFollowedUrl}?SerialNum=${SerialNum}`)
      .map(response => {
        return JSON.parse(response["_body"]).data})
  }

  //获得是否订阅的值
  getProjectSubscribe(SerialNum: string): Observable<any> {
    return this.http.get(`${this.getSubscriptionUrl}?SerialNum=${SerialNum}`)
      .map(response => {
        return JSON.parse(response["_body"]).data})
  }

  // 根据 项目的ID, 返回已经授权的分组或者个人
  getProjectAuthorises(pid:string): Observable<any> {
    return this.http.get(`${this.projectAuthorizedUrl}?pid=${pid}`)
      .map(response => {
        return JSON.parse(response["_body"]).data})
  }

  // 返回所有的分组信息
  getProjectTeamLists(pid:string): Observable<any> {
    return this.http.get(`${this.projectTeamListdUrl}?pid=${pid}`)
      .map(response => {
        return JSON.parse(response["_body"])})
  }
  getTeamMembers(teamArr:string[]): Observable<any> {
    return this.http.post(this.getTeamMembersUrl, {data: teamArr}, {headers: this.headers})
      .map(response => {
        return JSON.parse(response["_body"])})
  }


  //更新一个项目授权的团队和人
  updateProjectTeamLists(pid:string,teamIds:any): Observable<any> {
    teamIds = teamIds==""? -1 : teamIds;
    return this.http.put(this.projectUpdatePrivilegeUrl,{pid:pid,teamIds:teamIds},{headers:this.headers})
  }
  addPerAuth(uid:string,pid:string): Observable<any> {

    return this.http.put(this.addPerAuthUrl,{pid:pid,uid:uid},{headers:this.headers})
      .map(response => {
        return JSON.parse(response["_body"])})
  }
  getTeamsAuth(uid:string): Observable<any> {
    return this.http.get(`${this.getTeamsAuthUrl}?uid=${uid}`)
      .map(response => {
        return JSON.parse(response["_body"])})
  }

  // 通过关键字获得其人员列表
  searchtAddress(keyword:string):Observable<any> {
    return this.http.get(`http://api.zte.com.cn/api/zte-km-icenter-address/v1/rest/address/getAddressBook?keyword=${keyword}`)
      .map(response => {
        let items = [];
        if(!JSON.parse(response["_body"]).bo || !JSON.parse(response["_body"]).bo.length){
          return [];
        }
        let data= JSON.parse(response["_body"]).bo;
        data.forEach(item=>{
            let long={};
            long['uid'] = item.employeeShortId;
            long['name'] = item.name;
            long['dept'] = item.deptFullName;
            items.push(long);
        })
        return items
        })
  }

  // 发送邮箱
  seedMail(content: any){
    return this.http.post('/xplan/mail/send',content,{headers:this.headers})
      .map(response =>{
        return JSON.parse(response["_body"])
      })
  }
  // 判断一个人员的ID, 对某个项目是否有权限
  getAuthorized(pid: any,userId: any, synch?:boolean): any{
    // let me = this;
    if(!synch) {
      return this.http.get(`${this.projectIsAuthorizedUrl}?pid=${pid}&userId=${userId}`)
        .map(response => {
          return JSON.parse(response["_body"])
        })
    // }
    }else{
      return $.ajax({
        type: "GET",
        url: this.projectIsAuthorizedUrl,
        data: {"pid": pid,"userId":userId},
        async: false,
        dataType: "json",
        success: function(data){
          return data
        }
      });
    }
  }

  getSmAuth(pid: any){
    return this.http.get(`${this.getSmAuthUrl}?pid=${pid}`)
      .map(response =>{
        return JSON.parse(response["_body"])
      })
  }
  // 检查其人是不是在数据库人员列表中
  testUserID(uId: any){
    return this.http.get(`${this.testUserIDUrl}?uId=${uId}`)
      .map(response =>{
        return JSON.parse(response["_body"])
      })
  }

  // 给团队里加一个人
  addTeamPerson(uid: string,team: string){
    return this.http.get(`${this.addPersonUrl}?uid=${JSON.stringify(uid)}&team=${team}`)
      .map(response =>{
        return JSON.parse(response["_body"])
      })
  }

  // 获得其项目授权了的所有成员的ID的数组
  getAuthorOfficer(pid: any){
    pid = JSON.stringify(pid);
    return this.http.get(`${this.authorOfficerUrl}?pid=${pid}`)
      .map(response =>{
        return JSON.parse(response["_body"])
      })
  }

  getPrototypeZip(name: string){//给项目原型打包
    name = encodeURIComponent(name);
    return this.http.get(`${this.prototypeZip}?name=${name}`)
      .map(response =>{
        return response
      })
  }

  getImagesZip(name: string){//给项目图片打包
    name = encodeURIComponent(name);
    return this.http.get(`${this.imagesZip}?name=${name}`)
      .map(response =>{
        return ''
      })
  }
  getProjectsRelated(keyword: string){//获得项目相关
    keyword = encodeURIComponent(keyword);
    return this.http.get(`${this.projectsRelated}?keyword=${keyword}`)
      .map(response =>{
        return JSON.parse(response["_body"])
      })
  }
  getProjectListFilter(keyword?: string){//获得项目相关
    keyword = encodeURIComponent(keyword);
    return this.http.get(`${this.projectListFilter}?keyword=${keyword}`)
      .map(response =>{
        return JSON.parse(response["_body"])
      })
  }
  getUserInfo(uid?: string){// 获得项目相关
    return this.http.get(`${this.userInfoUrl}${!!uid?'?uid='+uid:""}`)
      .map(response =>{
        return JSON.parse(response["_body"])
      })
  }

  // 获得新手指导数据
  getGuidanceInfor(): Observable<any> {
    return this.http.get(this.guidanceInfor)
      .map(response => {
        return JSON.parse(response["_body"])})
  }

  // 更新指导数据
  updateGuidance(params: object){
    return this.http.post(this.updateGuidanceUrl, {data: params}, {headers: this.headers})
  }

  getAuthorizeHtml(info: any,projectName: string){
    info.dept = this.getformat(info.dept);
      let canformat = projectName.match(/\](\S*)/);
      projectName = !!canformat ? canformat[1] : projectName;
      let text = `<div style="
        font-family: 'Microsoft Yahei', Verdana, Simsun;
        width: 500px;
        margin: 0 auto;
        margin-top: 50px;
        box-sizing: border-box;
        background-color: #fff;
        box-shadow: 0 0 46px 5px rgba(0,0,0,.29);
        color: #888;
        text-align: center;">
  <ul style="padding:1px">
    <li style="margin: 30px 0 15px;">
      <img style="width: 42px;height: 50px;" src="http://rdk.zte.com.cn/assets/img/authorized.png" alt="权限安全">
    </li>
    <li style="margin: 0 auto;color: #888;">
      <h2 style="font-weight: 500;font-size: 24px;">为您开通了以下项目</h2>
      <div style="font-size: 16px;line-height: 30px;">
       <p style="width: 300px;margin: 0 auto;margin-bottom: 20px;font-size: 30px;font-weight:bold;white-space: nowrap;
                text-overflow: ellipsis;
                -o-text-overflow: ellipsis;
                overflow: hidden;color: #288bf0;" title="${projectName}">${projectName}</p>
      
        <p class=" white-space: nowrap;
                   text-overflow: ellipsis;
                   -o-text-overflow: ellipsis;
                   overflow: hidden;">管理员&nbsp;&nbsp;${info.name} &nbsp;&nbsp;${info.uid}</p>
        <p style="width: 300px;margin: 0 auto;white-space: nowrap;
                text-overflow: ellipsis;
                -o-text-overflow: ellipsis;
                overflow: hidden;" title="${info.dept}">${info.dept}</p>
        <p style="font-size: 14px;">需持续收到该项目更新：请打开此项目，点击项目标题下面的 
          <img src="http://rdk.zte.com.cn/assets/img/subscribe.png" alt="订阅"></img>
         </p> 
       
      </div>
       
    </li>
    <li>
      <a style="display: inline-block;width: 118px;
      height: 36px;
      margin-top: 10px;
      margin-bottom: 15px;
      line-height: 36px;
      border-radius: 18px;
      background-color: #288bf0;
      color: #fff;
      font-size: 16px;text-decoration: none;" href="${window.location.origin + window.location.pathname}">立即查看</a>
    </li>
  </ul>
</div>
<div style="width: 500px;margin: 0 auto;margin-top: 20px;text-align: center;font-size: 14px;font-family: 'Microsoft Yahei', Verdana, Simsun">
    请设置邮箱打开链接的默认浏览器为 Google浏览器后可以点击上面“直接查看” 或 直接
    复制 <a href="${window.location.origin + window.location.pathname}">${window.location.origin + window.location.pathname}</a>此链接在Google浏览器中打开！
</div>
`;
 return text;

  }

  getEmailTemp(info: any,project?:Project, isSuccss: boolean = true){// 申请授权的模板
    if(!info || !project){
      return "请传参数 ： info";
    }
    info.dept = this.getformat(info.dept);
   let projectName = !!project.ProjectName.match(/\](\S*)/)?project.ProjectName.match(/\](\S*)/)[1]:project.ProjectName
    return `<div style="
        font-family: 'Microsoft Yahei', Verdana, Simsun;
        width: 500px;
        height: 320px;
        margin: 0 auto;
        margin-top: 50px;
        box-sizing: border-box;
        background-color: #fff;
        box-shadow: 0 0 46px 5px rgba(0,0,0,.29);
        color: #888;
        text-align: center;">
  <ul style="padding:1px">
    <li style="margin: 30px 0 15px;">
      <img style="width: 42px;height: 50px;" src="http://rdk.zte.com.cn/assets/img/authorized.png" alt="权限安全">
    </li>
    <li style="margin: 0 auto;">
      <h2 style="margin-bottom: 10px;color: #4498f0;font-size: 30px;">${isSuccss?"UED项目权限申请":"恭喜您，项目申请成功！"}</h2>
      <div style="font-size: 16px;line-height: 30px;">

        <p>${info.name} &nbsp;&nbsp;${info.uid}</p>
        <p style="width: 300px;margin: 0 auto;white-space: nowrap;
                text-overflow: ellipsis;
                -o-text-overflow: ellipsis;
                overflow: hidden;">${info.dept}</p>
        <p style="width: 300px;margin: 0 auto;white-space: nowrap;
                text-overflow: ellipsis;
                -o-text-overflow: ellipsis;
                overflow: hidden;color: #288bf0;">${isSuccss?"向您申请查看":"申请查看"}：${projectName}</p>

      </div>
       
    </li>
    <li>
      <a style="display: inline-block;width: 118px;
      height: 36px;
      margin-top: 10px;
      line-height: 36px;
      border-radius: 18px;
      background-color: #288bf0;
      color: #fff;
      font-size: 16px;" href="${isSuccss?'http://rdk.zte.com.cn/projects/detail/auth/?uid='+info.uid+'&pid='+project.SerialNum:'http://rdk.zte.com.cn/projects/'+project.SerialNum}">立即${isSuccss?'授权':'查看'}</a>
    </li>
  </ul>
</div>
`;
  }
}
