/**
 * Created by 6176000041 on 2017/7/27.
 */

export class Project {
  SerialNum:string;
  ProjectName: string;
  ProjectImg: string;
  ProjectType?: string;
  ProjectBrief:string;
  PrototypeView: any;
  PrototypeZip: string;
  RequirementDoc: any;
  Keywords: string;
  Creator: string;
  CreatTime: string;
  FavoriteRecord: string;
  VisitRecord: string;
  ActionType: string;
  Updator: string;
  UpdateTime: string;
  graphicZip: string;
  creatorId: string;
  updaterId: string;
  tagArr?:string[];
}
