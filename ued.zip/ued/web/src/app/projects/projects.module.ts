import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

/*路由&守卫*/
import {ProjectsRoutingModule} from "./projects-routing.module";
import {AuthGuard} from "./auth-guard";

/*模块*/
import {UedCommonModule} from "../common/ued-common.module";
import {HomeModule} from "../home/home.module";
import {
  JigsawButtonModule, JigsawInputModule, JigsawTagModule, JigsawTableModule, JigsawCheckBoxModule, JigsawRadioModule,
  JigsawLoadingModule
} from "@rdkmaster/jigsaw";
/*组件*/
import {ProjectDetailComponent} from "./project-detail/project-detail.component";
import {ProjectListComponent} from "./project-list/project-list.component";
import {ProjectService} from "./project-service/project.service";
import {FooterComponent} from "../home/footer/footer.component";
import {ProjectAuthComponent} from './project-auth/project-auth.component';
import {SplicePipe} from "./pipe/splice.pipe";
import {FileFormatPipe} from "./pipe/file-format.pipe";


@NgModule({
  imports: [
    CommonModule,
    ProjectsRoutingModule,
    JigsawButtonModule,
    JigsawInputModule,
    JigsawTagModule,
    JigsawTableModule,
    JigsawCheckBoxModule,
    JigsawRadioModule,
    JigsawLoadingModule,
    UedCommonModule,
    HomeModule
  ],
  declarations: [
    ProjectDetailComponent,
    ProjectListComponent,
    FooterComponent,
    ProjectAuthComponent,
    SplicePipe,
    FileFormatPipe
  ],
  entryComponents: [

  ],
  providers: [ProjectService, AuthGuard],
})
export class ProjectModule {
}
