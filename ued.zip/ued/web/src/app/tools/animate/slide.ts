/**
 * Created by 6396000843 on 2017/10/11.
 */
import { AnimationEntryMetadata } from '@angular/core';
import {trigger,state, transition, animate, style, query, group, keyframes, stagger, useAnimation, animation} from '@angular/animations';

export const listAnimation =
  trigger('listAnimation', [
    transition('* => *', [ // each time the binding value changes
      query(':enter', [
        style({ opacity: 0 }),
        stagger(100, [
          animate('0.618s cubic-bezier(0.000, 0.105, 0.035, 1.450)', keyframes([
            style({transform: 'translate3d(-100%, 0, 0)', offset: 0,opacity:0}),
            style({transform: 'translate3d(0, 0, 0)', offset: 1,opacity:1})
          ]))
        ])
      ],{ optional: true })
    ])
  ]);


