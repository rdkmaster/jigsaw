import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Tool} from "../tool";
import { ToolsService} from "../tools.service";
import { listAnimation } from "../animate/slide";
import { PLATFORM_ID,Inject } from '@angular/core';
import { isPlatformBrowser} from '@angular/common';
import 'rxjs/add/operator/switchMap';

@Component({
  selector: 'app-tools',
  templateUrl: './tool-list.component.html',
  styleUrls: ['./tool-list.component.scss'],
  animations: [ listAnimation ]
})
export class ToolListComponent implements OnInit {

  tools:Tool[];
  isBrowser:boolean=true;
  constructor(
    private toolsService: ToolsService,
    private route: ActivatedRoute,
    private router: Router,
    @Inject(PLATFORM_ID) private platformId : Object
  ) { }

  ngOnInit() {
    this.route.data
      .subscribe((data: { toolList: Tool[] }) => {
        setTimeout(()=>{ //异步获取toolList，否则listAnimation动画无效
          this.tools = data.toolList;
        },0);
        this.toolsService.toolList=data.toolList;
      });

    if (!isPlatformBrowser(this.platformId)) {
      this.isBrowser=false;
    }
  }
  onSelect(tool: Tool): void {
    this.router.navigate([tool.tid], { relativeTo: this.route });
  }

}
