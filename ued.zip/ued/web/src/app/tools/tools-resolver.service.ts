import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';

import { Tool } from './tool'
import { ToolsService} from "./tools.service";
import { Observable } from 'rxjs/Observable';

@Injectable()
export class ToolListResolver implements Resolve<Tool[]> {
  constructor(private toolsService: ToolsService) {}

  resolve(): Observable<Tool[]> {
    return this.toolsService.getTools()
  }
}


