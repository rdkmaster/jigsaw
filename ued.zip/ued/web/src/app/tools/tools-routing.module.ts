import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ToolListComponent } from "./tool-list/tool-list.component";
import { ToolDetailComponent } from "./tool-detail/tool-detail.component";
import { ToolListResolver } from "./tools-resolver.service";

const ToolsRoutes: Routes = [
  {
    path: '',  component: ToolListComponent,
    children:[
      {path:'', redirectTo:'1', pathMatch:'full'},
      { path: ':id', component: ToolDetailComponent}
    ],
    resolve: {
      toolList: ToolListResolver
    }
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(ToolsRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    ToolListResolver
  ]
})
export class ToolsRoutingModule { }
