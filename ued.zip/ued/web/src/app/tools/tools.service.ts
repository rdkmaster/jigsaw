import { Injectable } from '@angular/core';
import { Tool } from './tool'
import { HttpClient,HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class ToolsService {
  private queryToolsURL = 'rdk/service/app/ued/server/tools/tool-list';
  toolList:Tool[] = [];
  constructor(private http:HttpClient){}

  getTools():Observable<Tool[]>{
    return this.http
      .get(this.queryToolsURL)
  }

  getTool(id: number | string) {
    return this.toolList.find(tool => tool.tid == +id);
  }
}
