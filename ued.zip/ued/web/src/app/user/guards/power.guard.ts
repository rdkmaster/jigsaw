import { Injectable } from '@angular/core';
import {CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, ActivatedRoute} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import {UserLoginService} from "../user-login/user-login.service";
import {JigsawWarningAlert} from "@rdkmaster/jigsaw";

@Injectable()
export class PowerGuard implements CanActivate {
  constructor(private userLoginService:UserLoginService,
              private activeRoute: ActivatedRoute,
              private router: Router,
  ){}
  currentUser:any;
  isUseRole: boolean;
  loginMsg: any = null;
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    this.currentUser = this.userLoginService.currentUserGlobal;
    this.isUseRole = !!this.currentUser && this.currentUser.roles=="199";
    if(this.isUseRole) return true;
    this.loginMsg=JigsawWarningAlert.show('', answer => {},[],'您不是管理员，无法进入角色管理', false);
    setTimeout(()=>{
      this.loginMsg.dispose();
      this.router.navigate(['/home'], { relativeTo: this.activeRoute });
    },2000)
    return this.isUseRole;
  }
}
