export class User {
    uid: number;
    userName: string;
    email: string;
    password: string;
    confirmPassword: string;
    sex:string;
    phoneNumber: string;
    roles: string;
    team: string;
    dept: string;
    company:string;
    headPicture:string;
    remeberMe:boolean;
    token:string;
    vocation:string;
}
