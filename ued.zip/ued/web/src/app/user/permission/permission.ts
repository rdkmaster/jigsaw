export class Permission {
  uId: string;
  username: string;
  dept: string;
  team: string

}
