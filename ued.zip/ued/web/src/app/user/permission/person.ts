export class Person{
  username: string;
  uId: string;
  dept: string;
  team:　string
}
