import { ShowPipe } from './show.pipe';

describe('ShowPipe', () => {
  it('create an instance', () => {
    const pipe = new ShowPipe();
    expect(pipe).toBeTruthy();
  });
});
