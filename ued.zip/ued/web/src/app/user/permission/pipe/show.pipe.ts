import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'show'
})
export class ShowPipe implements PipeTransform {

  transform(value: any, key: any): boolean {
    if(key == "" && value && !!value.length){
      return false;
    }
    if(!value){
      return true;
    }
    let temp= value.filter(item => {
        for(let i in item) {
          if(Object.prototype.hasOwnProperty.call(item,i)) { //过滤
            if(item[i].indexOf(key)!=-1){
              return true;
            }
          }
        }
        return false
      })
    if(temp.length == 0 || !value){
      return true;
    }
      return false;
  }

}
