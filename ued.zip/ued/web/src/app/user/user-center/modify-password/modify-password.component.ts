import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modify-password',
  templateUrl: './modify-password.component.html',
  styleUrls: ['./modify-password.component.css']
})
export class ModifyPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
