"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var HeadPictureUploadComponent = (function () {
    function HeadPictureUploadComponent() {
        this.toggleShow = false;
        this.userPictureUpload = new core_1.EventEmitter();
        this.imgStartUpload = false;
    }
    HeadPictureUploadComponent.prototype.ngOnInit = function () {
        this.imgUploadUrl = this.user['headPicture'];
    };
    HeadPictureUploadComponent.prototype.toggleImgUpload = function (event) {
        this.toggleShow = true;
    };
    HeadPictureUploadComponent.prototype.toggleImgShow = function (event) {
        if (this.imgStartUpload) {
            return;
        }
        this.toggleShow = false;
    };
    /*
     * 图片上传前的回调！
     * */
    HeadPictureUploadComponent.prototype.onPhotoBeforeUpload = function () {
        this.imgStartUpload = true;
    };
    /*
     * 图片上传成功后的回调！
     * */
    HeadPictureUploadComponent.prototype.onPhotoUpload = function (event) {
        this.imgUploadUrl = event.xhr.response;
        this.imgStartUpload = false;
        this.toggleShow = false;
        this.userPictureUpload.emit({ imgUrl: this.imgUploadUrl });
    };
    __decorate([
        core_1.Input()
    ], HeadPictureUploadComponent.prototype, "user", void 0);
    __decorate([
        core_1.Output()
    ], HeadPictureUploadComponent.prototype, "userPictureUpload", void 0);
    __decorate([
        core_1.HostListener('mouseenter', ['$event'])
    ], HeadPictureUploadComponent.prototype, "toggleImgUpload", null);
    __decorate([
        core_1.HostListener('mouseleave', ['$event'])
    ], HeadPictureUploadComponent.prototype, "toggleImgShow", null);
    HeadPictureUploadComponent = __decorate([
        core_1.Component({
            selector: 'ued-head-picture-upload',
            templateUrl: './head-picture-upload.component.html',
            styleUrls: ['./head-picture-upload.component.css'],
            encapsulation: core_1.ViewEncapsulation.None
        })
    ], HeadPictureUploadComponent);
    return HeadPictureUploadComponent;
}());
exports.HeadPictureUploadComponent = HeadPictureUploadComponent;
