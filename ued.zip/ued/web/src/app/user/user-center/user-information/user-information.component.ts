import { Component, OnInit,ViewEncapsulation,Pipe,PipeTransform } from '@angular/core';
import {DomSanitizer, SafeHtml} from "@angular/platform-browser";
import { Router, ActivatedRoute, Params } from '@angular/router';
import {User} from "../../model/user-model";
import {UserLoginService} from "../../user-login/user-login.service";
import {UserCenterService} from "../service/user-center.service";
import {ArrayCollection} from "@rdkmaster/jigsaw";
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/debounceTime';

@Pipe({
  name: 'sanitizeResourceUrL'
})
export class SanitizeResourceUrLPipe implements PipeTransform {

  constructor(private _sanitizer:DomSanitizer) {
  }
  transform(v:string) {
    //  return this._sanitizer.bypassSecurityTrustResourceUrl("http://localhost:4200/"+v);
    return this._sanitizer.bypassSecurityTrustResourceUrl(v);
  }
}

@Component({
  selector: 'app-user-information',
  templateUrl: './user-information.component.html',
  styleUrls: ['./user-information.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class UserInformationComponent implements OnInit {

  //sexEnum:Array<object>=[{label:'女',value:0},{label:'男',value:1}];
  sexEnum = new ArrayCollection([
    {label: "女",value:0},
    {label: "男",value:1},
  ]);
  vocationEnum:Array<object>=[
    {label:'前端开发'},
    {label:'后端开发'},
    {label:'视觉设计师'},
    {label:'交互设计师'},
    {label:'用户研究'},
    {label:'产品经理'}
  ];
  constructor(
    public userLoginService: UserLoginService,
    private userCenterService:UserCenterService,
    private activeRoute: ActivatedRoute,
    private router: Router
  ) { }
  currentUser:User;
  selectedSex:any={};
  selectedVocation:any={};

  private saveUserInfo$ = new Subject<User>();

  ngOnInit() {
    this.currentUser=this.userLoginService.currentUserGlobal;
    this.selectedSex=this.sexEnum[this.currentUser.sex];
    this.selectedVocation = this.vocationEnum.find((item)=>{
      return item['label']==this.currentUser['vocation'];
    });

    this.saveUserInfo$
      .debounceTime(300)
      .switchMap((user:User)=>{
        return this.userCenterService.updateCurrentUserInfo(user)
      })
      .subscribe(
        data =>{
          if(data.status==1){
            this.userCenterService.sendMsg('saveUserInfo');
            this.userLoginService.saveCurrentUser(this.currentUser);
          }
        },
        error=>{
          console.error("信息修改失败:",error) }
      );
  }
  onUserPictureUpload(event){
    this.currentUser['headPicture']=event.imgUrl;
  }

  doCancel(){
    this.ngOnInit();
  }

  doSaveUserInfo(){
    this.currentUser['vocation']=this.selectedVocation && this.selectedVocation.label || "";
    this.currentUser['sex']=this.selectedSex && this.selectedSex.value;
    this.saveUserInfo$.next(this.currentUser);
  }
}
