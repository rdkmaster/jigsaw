import { Component, EventEmitter, Output,OnInit } from '@angular/core';
import {User} from "../model/user-model";
import { fadeIn } from '../../animations/fade-in';
import {UserLoginService} from "./user-login.service";
import { VersionControlService,Version} from "../../admin/version/version-control.service";

@Component({
  selector: 'ued-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css'],
  animations: [ fadeIn ]
})
export class UserLoginComponent implements OnInit{


  @Output() onRegister = new EventEmitter();
  public user:User = new User();

  public error : Error;

  public version:Version;

  constructor(private userLoginService:UserLoginService) { }

  loginMsg:string='';
  ngOnInit():void {
    this.version=VersionControlService.version;
    this.user.remeberMe=true;
    this.userLoginService.userLoginMsg.subscribe(loginMsg=>this.loginMsg=loginMsg)
  }

  cleanMsg(){
    this.loginMsg='';
  }
  doLogin(){
    this.userLoginService.login(this.user);
  }
  registerUser(){
    this.onRegister.emit();
  }
}
