/**
 * Created by 6396000843 on 2017/8/4.
 */
import { Injectable,PLATFORM_ID ,Inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Http, Headers, Response,RequestOptions, Request, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/switchMap';
import { Subject } from 'rxjs/Subject';
import { User } from '../model/user-model';
import { rsa }  from './rsa';
import { VersionControlService} from "../../admin/version/version-control.service";
import {AppAnalysisService} from "../../app.analysis.service";

@Injectable()
export class UserLoginService {

  private userLoginURL = 'rdk/service/app/ued/server/user/user-login';
  private userLoginOutURL = 'rdk/service/app/ued/server/user/user-login-out';
  private preparekeyURL = 'xplan/common/preparekey';
  //http://api.zte.com.cn/api/zte-km-icenter-address/v1/rest/user/queryUserCard?curEmployeeShortId=%27%27&employeeShortId=6396000843
  private userCardURL = 'http://10.31.3.72/api/zte-km-icenter-address/v1/rest/user/queryUserCard';

  private saveLoginURL = 'rdk/service/app/ued/server/user/save-login';

  public userInfo$: Subject<User> = new Subject<User>();
  public userLoginErrorMsg$: Subject<string> = new Subject<string>();

  public redirectUrl:string="";
  public isLogin:boolean=false;
  public openLoginProp$: Subject<boolean> = new Subject<boolean>();

  publicKey:any;
  rsa :any;
  isInward:boolean;

  constructor(
    private http:Http,
    private activeRoute: ActivatedRoute,
    private router: Router,
    private analysisService: AppAnalysisService,
    @Inject(PLATFORM_ID) private platformId : Object

  ){
    this.isInward=VersionControlService.versionFlag=="inward";
    if (isPlatformBrowser(platformId) && this.isInward) {
      // RSA
      this.rsa = rsa.init();
      // 获取公钥
      this.requestPublicKey()
        .subscribe(
          data => {this.publicKey =  data},
          error => {
            console.error("获取公钥失败",error);
            this.userLoginErrorMsg$.next("Sorry!服务器出问题了，请稍后再试");
          }
        );
    }

    if (isPlatformBrowser(platformId)) {
      this.requestSaveLogin()
        .subscribe(
          (user:User) => {
            if(!user){
              console.warn("login timeout");
              localStorage.removeItem("currentUser");
              this.userInfo$.next(null);
            }
          },
          error => {
            this.userLoginErrorMsg$.next("Sorry!服务器出问题了，请稍后再试");
          }
        );
    }
  }

  //返回登陆失败提示信息
  public get userLoginMsg():Observable<string>{
    return this.userLoginErrorMsg$.asObservable();
  }

  //获取已登陆用户 Observable
  public get currentUser():Observable<User>{
    return this.userInfo$.asObservable();
  }
  //获取已登陆用户 Object
  public get currentUserGlobal():User{
    if (isPlatformBrowser(this.platformId)) {
      return JSON.parse(localStorage.getItem("currentUser"))
    }
    return null
  }

  // 请求公钥
  requestPublicKey():any{
    return this.http
      .get(this.preparekeyURL)
      .map((response: Response) => {
        return response.json();
      });
  }

  // 判断用户是否已登陆过，自动登陆
  requestSaveLogin():any{
    if (isPlatformBrowser(this.platformId)) {
      return this.http
        .get(this.saveLoginURL)
        .map((response: Response) => {
          return response.json()["currentUser"];
        });
    }
  }

  // 请求登陆
  private _requestLogin(authData){
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let reqOptions = new RequestOptions({ headers: headers ,body:authData});
    return this.http
      .post(this.userLoginURL,null,reqOptions)
      .distinctUntilChanged()
      .map((response: Response) => {
        return response.json();
      })
      .map(this.isLoginSuccess.bind(this))
      .map(this.transformUserObj);
  }

  // 退出登陆
  private requestLoginOut(){
    return this.http
      .get(this.userLoginOutURL)
      .map((response: Response) => {
        this.analysisService.resetUser();
        return response.json();
      })
  }

  //查询用户信息 --公司接口获取初始信息
  private requestQueryUserCard(user:User){
    return this.http
      .get(this.userCardURL+`?curEmployeeShortId=''&employeeShortId=${user.uid}`)
      .distinctUntilChanged()
      .map((response: Response) => {
        return response.json();
      })
      .map(this.transformUserCardInfo)
  }

  isLoginSuccess(resUserData){
    //登陆失败，返回错误提示信息
    if(resUserData.status=="0"){
      resUserData.contents && this.userLoginErrorMsg$.next(resUserData.contents["message"]);
    }

    if(resUserData.status=="1"&& resUserData.contents.uid) { // 登录成功.
      this.analysisService.setUserInfo(resUserData.contents.uid);
    }
    return resUserData
  }

  transformUserObj(resUserData){
    let user: User={
      token:resUserData.tokens,
      uid:resUserData.contents.uid,
      userName:resUserData.contents.name,
      roles:resUserData.contents.roles,
      team:resUserData.contents.team,
      dept:resUserData.contents.dept,
      email:resUserData.contents.mail,
      sex:resUserData.contents.sex || "",
      password: "",
      confirmPassword: "",
      phoneNumber: resUserData.contents.phoneNumber || "",
      company:resUserData.contents.company || "",
      headPicture:resUserData.contents.headPicture || "",
      remeberMe:true,
      vocation:resUserData.contents.vocation || "",
    };
    return user
  }

  transformUserCardInfo(data:any){
    var user = new User();
    if(data['bo'] && data['bo'][0]){
      user.sex=data['bo'][0].sex;
      user.email=data['bo'][0].email;
      user.company=data['bo'][0].deptFullName;
      if(data['bo'][0].contactList && data['bo'][0].contactList[0] && data['bo'][0].contactList[0].mainNumber){
        user.phoneNumber= data['bo'][0].contactList[0].mainNumber;
      }
    }
    return user
  }
  // RSA加密
  private encrypt = (keyInfo, str) => {
     let key = new this.rsa.getKeyPair(keyInfo.exponent,"",keyInfo.modules);
     return this.rsa.encryptedString(key, str);
  };

  public login(user:User){
    if(this.isInward){  //内部登陆
      this._inwardLogin(user);
    }else{
      this._outwardLogin(user);
    }
  }

  private _outwardLogin(user:User){
    console.log("外部登陆功能暂未实现............");
    let authData = {
      keyID: "ued12345678", //密钥
      password: user.password,
      userID: user.userName,
      remeberMe:user.remeberMe,
    };
    this._requestLogin({user:authData,version:"outward"})
      .subscribe(
        (user:User)=>{
          if(user && user.token){
            //保存登陆用户
            this.saveCurrentUser(user);
            this.isLogin=true;
            if(this.redirectUrl!=""){
              this.router.navigate([this.redirectUrl]);//跳转到被登陆拦截前的页面
            }
          }
        },
        this.handleError.bind(this)
      );
  }

  private _inwardLogin(user:User){
    // 请求数据 --登陆接口用了eban的，数据按照它的接口来包装
    let authData = {
      keyID: this.publicKey && this.publicKey.keyId,
      password: this.encrypt(this.publicKey, user.password),
      userID: user.userName,
      remeberMe:user.remeberMe
    };
    // 请求登陆
    this._requestLogin({user:authData,version:"inward"})
      .subscribe(
        (user:User)=>{
          if(user){
            this.requestQueryUserCard(user) //请求公司提供的接口，查询用户的详细信息
              .subscribe(data=>{
                //保存登陆用户
                user = Object.assign(data,user);
                this.saveCurrentUser(user);
                this.isLogin=true;
                if(this.redirectUrl!=""){
                  this.router.navigate([this.redirectUrl]);//跳转到被登陆拦截前的页面
                }
              })
          }
        },
        this.handleError.bind(this)
      );
  }

  //todo:暂时保存在localStorage,需要保存在cookie里
  public saveCurrentUser(user:User){
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem("currentUser",JSON.stringify(user));
      this._removeCookie("token");
      this._removeCookie("uId");
      this._setCookie("token",user.token);
      this._setCookie("uId",-1);
      this.userInfo$.next(Object.assign({},user));
    }
  }

  //登陆成功
  private handleLoginSucces(user){}
  //错误处理
  private handleError(err){
    console.error(err);
    this.userLoginErrorMsg$.next("Sorry！服务器出问题了，请稍后再试");
  }
  public logout():void{
    this.requestLoginOut().subscribe(
      respose=>{
        if(respose.status){
          localStorage.removeItem("currentUser");
          this._removeCookie("token");
          this.userInfo$.next(null);
          this.isLogin=false;
          this.redirectUrl="";
          this.router.navigate(['/home'], { relativeTo: this.activeRoute });
        }
      }
    );
  }

  private _setCookie(name,value) {
    var Days = 30;
    var date = new Date();
    date.setTime(date.getTime() + Days*24*60*60*1000);
    document.cookie = name + "="+ window["escape"](value) + ";expires=" + date["toGMTString"]()+";path=/";
  }

  private _removeCookie(name) {
    var date = new Date(); //获取当前时间
    date.setTime(date.getTime()-10000); //将date设置为过去的时间
    document.cookie = name + "=v; expires =" + date["toGMTString"]();//设置cookie
  }
}

