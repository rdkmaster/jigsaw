import { Component, OnInit} from '@angular/core';

import {UserLoginService} from "../../user/user-login/user-login.service";

import {Router} from "@angular/router";

@Component({
  selector: 'ued-user-menu',
  templateUrl: './user-menu.component.html',
  styleUrls: ['./user-menu.component.scss']
})
export class UserMenuComponent implements OnInit {

  public currentUser: any;
  public isUseRole: boolean = false;
  constructor(private userLoginService:UserLoginService) { }
  ngOnInit(){
    this.currentUser = this.userLoginService.currentUserGlobal;
    this.isUseRole = !!this.currentUser && this.currentUser.roles=="199";
    this.userLoginService.currentUser
      .subscribe(
        data=>{this.currentUser = data;},
        error => console.error(error)
      )
  }

  doOutLogin(){
    this.userLoginService.logout()
  }

}
