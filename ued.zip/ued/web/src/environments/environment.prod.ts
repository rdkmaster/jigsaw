export const environment = {
  production: true,
  version: 'inward'
};
