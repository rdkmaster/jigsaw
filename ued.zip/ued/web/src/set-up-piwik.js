function getlocalStorage(key) { //读取cookies: 系统火狐没有对应的UID cookies
  try {
    var userInfo = JSON.parse(localStorage[key]);

    if (!userInfo || userInfo == null) return ""; // 如果没有值,返回空

    return userInfo.uid;
  } catch (e) { // 报错返回空.
    return "";
  }
}

var _paq = _paq || [];
/* tracker methods like "setCustomDimension" should be called before "trackPageView" */
// 取得默认的用户名.
var uId = getlocalStorage("currentUser");

if (uId) {
  _paq.push(['setUserId', uId]);
}
_paq.push(['trackPageView']);
_paq.push(['enableLinkTracking']);

// 判断正式环境和测试环境.
var port = window.location.port;
var siteId = 0;  // 默认不监控本地调试的数据
if (!port || port == '80') { // 端口为空, 默认80端口, 为正式环境.
  siteId = '1';
} else if (port == "40080") { // 测试环境40080.
  siteId = '3';
}

if (siteId) { // 只有 正式和 40080 会进行监控.
  (function () {
    var u = "//10.9.225.190:8008/piwik/";
    _paq.push(['setTrackerUrl', u + 'piwik.php']);
    _paq.push(['setSiteId', siteId]);
    var d = document, g = d.createElement('script'), s = d.getElementsByTagName('script')[0];
    g.type = 'text/javascript';
    g.async = true;
    g.defer = true;
    g.src = u + 'piwik.js';
    s.parentNode.insertBefore(g, s);
  })();
}
