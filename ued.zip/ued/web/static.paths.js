module.exports = [
  '/home',
  '/team'
];
